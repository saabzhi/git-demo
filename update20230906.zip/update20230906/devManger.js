/**
 * 设备管理
 * @author HuangKunping
 */
$(function(){
	
	$("#searchBtn").closest("form").css("margin-bottom", "10px").css("margin-top", "10px");
	
	initDialog();
	
	initStopDialog();
	
	initList();
	
	$("#batchEnable").click(function(){
		createDevBatchEnabledDiag();
	});
	
	$("#batchStop").click(function(){
		createDevBatchDisabledDiag();
	});
	
	$("#importExcel").click(function(){
		$("#importDevice").dialog("open");
	});
	
	$("#importBtn").click(function(){
		deviceImport();
	});
	
	deviceTypeList("#eq_deviceType", "<option value=''>-全部-</option>");
	
	deviceTypeList(".deviceType");
	
	$("#choseOrgNo").click(function(){
	var organizationSid = top.loginPeopleInfo.orgSid;
	//var organizationSid = "00000000000000000000000000000000";
		$("#ownerOrganizationName").dialogOrgTree("radio", organizationSid, false, null,null, function(event, treeId, treeNode){
			if(treeNode){
				$("#ownerOrganizationName").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
				$("#ownerOrganization").val(treeNode.sid);
			}
		});
	});
	
	$("#searchOrgNo").click(function(){
	var organizationSid = top.loginPeopleInfo.orgSid;
	//var organizationSid = "00000000000000000000000000000000";
		$("#ownerOrgNameSearch").dialogOrgTree("radio", organizationSid, false, null,null, function(event, treeId, treeNode){
			if(treeNode){
				$("#ownerOrgNameSearch").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
				$("#eq_ownerOrganization").val(treeNode.sid);
			}
		});
	});
	
	$("#searchBtn").click(function(){
		$("#list").jqGrid("search", "#search");
	});
	
	$("#clearBtn").click(function(){
		$(this).closest("form")[0].reset();
	});
	
});

function initDialog() {
	
	$("#importDevice").dialog({
        autoOpen : false,
        height : 260,
		width : 700,
        resizable : false,
        modal : true
    });
	
	$("#sealInstallInfo").dialog({
        autoOpen : false,
        height : 360,
		width : 875,
        resizable : false,
        modal : true
    });
	
	$("#devManger").dialog({
        autoOpen : false,
        height : 200,
        width : 400,
        resizable : false,
        modal : true,
        buttons : {
        	"保存":function() {
        		var _this = this;
        		if(!$("#ownerOrganizationName").val()) {
        			alert("请选择所属机构!");
					return;
        		}
        		if (!$(this).validationEngine("validate")) {
                    return;
                 }
        		var reg = /^[A-Za-z0-9]+$/;
        		var deviceNum = $("#deviceNum").val();
        		var autoId = $("#autoId").val();
        		if (checkExistOfDeviceNum(autoId, deviceNum)) {
        			alert("设备编号已存在!");
					return;
				}
        		if (!reg.test(deviceNum)) {
        			alert("设备编号只能由字母和数字组成！");
        			return;
        		}
        		if (deviceNum.length < 9) {
        			alert("设备编号不能小于9位！");
        			return;
        		}
        		var deviceStatus = $("#deviceStatus").val();
        		if(deviceStatus==6){
	        		if (confirm("是否确认销毁此印控机？")){
		        		$.post(top.ctx + "/mms/managerSealDeviceAction!save.action", 
		            			$(this).serializeForm(), function(data) {
		        			if (data.responseMessage.success) {
		        				$.success("保存成功.");
		        				$(_this).dialog("close");
		        				$("#list").jqGrid("search", "#search");
							} else {
								$.error(data.responseMessage.message);
							}
		            	});
	        		}
        		}else{
        			$.post(top.ctx + "/mms/managerSealDeviceAction!save.action", 
	            			$(this).serializeForm(), function(data) {
	        			if (data.responseMessage.success) {
	        				$.success("保存成功.");
	        				$(_this).dialog("close");
	        				$("#list").jqGrid("search", "#search");
						} else {
							$.error(data.responseMessage.message);
						}
	            	});
        		}
        	}
        },
        close: function() {
        	$(this)[0].reset();
        	$(this).validationEngine("hideAll");
        }
	});
	
	$("#newDevice").click(function(){
		$("#devManger").dialog("open");
	});
	
	$("#devManger").validationEngine({
        showOnMouseOver:true,
        validationEventTrigger:"keyup blur",
        promptPosition : "centerRight",
        autoPositionUpdate : true,
        onValidationComplete: function() {}
    });
}

function initStopDialog() {
	$("#devMangerStop").dialog({
        autoOpen : false,
        height : 200,
        width : 400,
        resizable : false,
        modal : true,
        buttons : {
        	"停用确认":function() {
        		var _this = this;
        		if (!$(this).validationEngine("validate")) {
                    return;
                 }
        		$.post(top.ctx + "/mms/managerSealDeviceAction!stop.action", 
            			$(this).serializeForm(), function(data) {
        			if (data.responseMessage.success) {
        				$.success("停用操作成功.");
        				$(_this).dialog("close");
        				$("#list").jqGrid("search", "#search");
					} else {
						$.error("停用操作失败.");
					}
            	});
        	}
        },
        close: function() {
        	$(this)[0].reset();
        	$(this).validationEngine("hideAll");
        }
	});
	
	
	$("#devBatchDisabledDLG").dialog({autoOpen: false,caption:"设备批量停用", resizable: false,height: 315,width:510,modal: true,buttons: {
		"停用": function() {
			$.post(top.ctx + "/mms/managerSealDeviceAction!stop.action", 
					$("#devBatchDisabled_item").serializeForm(), function(data) {
    			if (data.responseMessage.success) {
    				$.success("批量停用操作成功.");
    				$("#devBatchDisabledDLG").dialog("close");
    				$("#list").jqGrid("search", "#search");
				} else {
					$.error("批量停用操作失败.");
				}
        	});
		},"关闭": function() {//5
			$("#devBatchDisabledDLG").dialog("close");
		}},close: function() {
			$("#devBatchDisabled_item")[0].reset();
		}
	});
	
	$("#devBatchEnabledDLG").dialog({autoOpen: false,caption:"设备批量启用", resizable: false,height: 315,width:510,modal: true,buttons: {
		"启用": function() {
			$.post(top.ctx + "/mms/managerSealDeviceAction!enable.action", 
					$("#devBatchEnabled_item").serializeForm(), function(data) {
    			if (data.responseMessage.success) {
    				$.success("批量启用操作成功.");
    				$("#devBatchEnabledDLG").dialog("close");
    				$("#list").jqGrid("search", "#search");
				} else {
					$.error("批量启用操作失败.");
				}
        	});
		},"关闭": function() {//5
			$("#devBatchEnabledDLG").dialog("close");
		}},close: function() {
			$("#devBatchEnabled_item")[0].reset();
		}
	});
}

function deviceTypeList(id, defaultOption) {
	var options = "";
	if (defaultOption) {
		options = defaultOption;
	}
	var datas = GPCache.get(GPCache.GSS, GPType.MMS_DEVICE_TYPE);
	for (var i = 0; i < datas.length; i++) {
		if (datas[i]) {
			options += ("<option value=\"" + datas[i].paramKey + "\">" + datas[i].paramValue + "</option>");
		}
	}
	$(id).html(options);
}

function initList() {
	$("#list").jqGrid({
		caption : "印控设备列表",
		url : top.ctx+"/mms/managerSealDeviceAction!list.action",
		rowList:[10, 15, 20, 30],
		multiselect: true,
		rowNum:15,
		rownumbers : true,
		altRows : true,// 就是隔行用不同的背景色区分开
		colNames : [ "", "设备编号", "设备类型", "设备状态", "使用机构", "录入人", "录入机构", "录入时间", "印章详情", "操作" ],
		colModel : [ {
			name:"autoID",
			index:"autoID",
			hidden:true,
			width:"0px"
		}, {
			name : "deviceNum",
			index : "deviceNum",
			width : 180
		}, {
			name : "deviceType",
			index : "deviceType",
			width : 80,
			formatter:function(value, options, rData){
	   			return GPCache.get(GPCache.GSS, GPType.MMS_DEVICE_TYPE, value);
	   		}
		}, {
			name : "deviceStatus",
			index : "deviceStatus",
			width : 180,
			formatter:function(value, options, rData){
	   			return fetchSealDevStatus(value) /*+ "(" + fetchSealDevSubStatus(rData.deviceSubStatus) + ")"*/;
	   		}
		}, {
			name : "ownerOrganization",
			index : "ownerOrganization",
			width : 200,
			formatter:"organization"
		}, {
			name : "initPerson",
			index : "initPerson",
			width : 180,
			formatter:function(value, options, rData){
	   			return Personnel.getFormatPersonnel(value);
	   		}
		}, {
			name : "initOrganization",
			index : "initOrganization",
			width : 200,
			formatter:"organization"
		}, {
			name : "initDate",
			index : "initDate",
			width : 180
		}, {
			name : "holdOrganization",
			index : "holdOrganization",
			width : 80,
			align:"center",
			formatter:function(value, options, rData){
				return "<img src='"+ top.ctx + "/mms/common/images/show-icon.gif' style='cursor:pointer;margin-left:3px;' alt='查看详情'  title='查看详情' onclick='sealInstallView(\""+rData.deviceNum+"\");'/>";
   			}
		}, {
			name : "holdOrganization",
			index : "holdOrganization",
			width : 180,
			formatter:function(value,options,rData) {
				return addIcons(rData.autoID, rData);
			}
		}
		],
		pager : "#pager",
		gridComplete: function() {
            var rowIds = jQuery("#list").jqGrid("getDataIDs");
            for(var k=0; k<rowIds.length; k++) {
               var curRowData = jQuery("#list").jqGrid('getRowData', rowIds[k]);
               var curChk = $("#"+rowIds[k]+"", jQuery("#list")).find(":checkbox");
               curChk.attr('name', 'deviceNumCHKBOX');   //给每一个checkbox赋名字
               curChk.attr('value', curRowData['autoID']);   //给checkbox赋值
            } 
        }
	});
	
	$("#list").navGrid("#pager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true,
		excel: ctx + "/mms/sealDeviceReportAction!report.action"
	});
	/*$("#list").navButtonAdd('#pager',{
		   caption:"批量停用", 
		   buttonicon:"ui-icon-excel", 
		   onClickButton: function(){ 
			   createDevBatchDisabledDiag();
		   }, 
		   position:"last"
	});
	$("#list").navButtonAdd('#pager',{
		   caption:"批量启用", 
		   buttonicon:"ui-icon-excel", 
		   onClickButton: function(){ 
			   createDevBatchEnabledDiag();
		   }, 
		   position:"last"
	});*/
}


function addIcons(autoId, rData) {
	var html = "";
	if(rData.deviceStatus != "6") {
		html = "<a onclick='editDev(\""+ autoId +"\")' style='cursor: hand;'><font color='red'>修改</font></a>";
	}
	if(rData.deviceStatus == "3") {
		html += "&nbsp;|&nbsp;<a onclick='enableDev(\""+ autoId +"\")' style='cursor: hand;'><font color='red'>启用</font></a>";
	}
	if(rData.deviceStatus == "2") {
		html += "&nbsp;|&nbsp;<a onclick='stopDev(\""+ autoId +"\")' style='cursor: hand;'><font color='red'>停用</font></a>";
	}
	if(rData.deviceStatus != "6") {
		html += "&nbsp;|&nbsp;<a onclick='deleteDev(\""+ autoId +"\", \"" + rData.deviceNum + "\")' style='cursor: hand;'><font color='red'>删除</font></a>";
	}
	return html;
	
}

function editDev(autoId) {
	$.post(top.ctx + "/mms/managerSealDeviceAction!findById.action", 
			{"sealDevice.autoID" : autoId}, function(data) {
		if (data.responseMessage.success) {
			$("#devManger").fillForm({sealDevice : data.sealDevice});
			$("#ownerOrganizationName").val(Organization.getOrganization(data.sealDevice.ownerOrganization).organizationName);
			$("#devManger").dialog("open");
		}
	});
}


function stopDev(autoId) {
	$.post(top.ctx + "/mms/managerSealDeviceAction!findById.action", 
			{"sealDevice.autoID" : autoId}, function(data) {
		if (data.responseMessage.success) {
			$("#devMangerStop").fillForm({sealDevice : data.sealDevice});
			$("#ownerOrgName_stop").val(Organization.getOrganization(data.sealDevice.ownerOrganization).organizationName);
			$("#devMangerStop").dialog("open");
		}
	});
}

function deleteDev(autoId, deviceNum) {
	$.ajax({
		type : "POST",
		url : top.ctx + "/mechseal/sealinstall/sealInstallConfigAction_findByDeviceNum.action",
		data : {"sealInstallConfig.deviceNum" : deviceNum},
		dataType : "json",
		async : false,
		success : function(data) {
			if (!data.responseMessage.success) {
				$.error("设备编号查询印章安装信息失败.");
				return;
			}
			if (data.sealInstallConfigs.length > 0) {
				alert("该设备安装有印章，不可进行删除操作.");
			} else {
				$.del(top.ctx + "/mms/managerSealDeviceAction!delete.action", {"sealDevice.autoID" : autoId});
			}
		}
	});
}

function enableDev(autoId) {
	$.post(top.ctx + "/mms/managerSealDeviceAction!enable.action", 
			{"sealDevice.autoID" : autoId}, function(data) {
		if (data.responseMessage.success) {
			$.success("启用：操作成功.");
			$("#list").jqGrid("search", "#search");
		} else {
			$.error("启用：操作失败.");
		}
	});
}

function checkExistOfDeviceNum(autoId, deviceNum) {
	var result = false;
	$.ajax({
		type : "POST",
		url : top.ctx + "/mms/managerSealDeviceAction!checkExistOfDeviceNum.action",
		data : {"sealDevice.autoID" : autoId, "sealDevice.deviceNum" : deviceNum},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data.responseMessage.success) {
				result = data.responseMessage.data;
			} else {
				$.error("检测设备编号是否存在失败.");
			}
		}
	});
	return result;
}


/**
 * 批量停用
 */
function createDevBatchDisabledDiag(){
	var checkedVals = new Array();
	$(":checkbox[name=deviceNumCHKBOX][checked]").each(function(){
		checkedVals.push($(this).val());
	});
	if(checkedVals.length < 1){
		alert("请选择需要停用的设备.");
		return;
	}

	// 显示需要处理的设备id列表
	var devBatchHandleListContent = "";
	var selectRows = $("#list").jqGrid('getGridParam','selarrrow');  // 取出已选择的行
	$.each(selectRows, function (index, rowId) {
		var rowData = $("#list").jqGrid('getRowData', rowId);
		if (rowData != null) {
			var deviceStatus = rowData["deviceStatus"];
			if (deviceStatus == "启用") {
				devBatchHandleListContent += "<option value='"+rowData["autoID"] +"'>"+rowData["deviceNum"]+"</option>";
			} else {
				alert("设备编号为：" + rowData["deviceNum"] + ", 该状态下不可停用!");
			}
		}
	});
	if (devBatchHandleListContent == "") {
		return;
	}
	$("#devBatchHandleDevNumsItem").html(devBatchHandleListContent);

	$("#sealBatchDisabledDeviceSidItem").val(checkedVals);
	$("#devBatchDisabledDLG").dialog("open");
}

/**
 * 批量启用
 */
function createDevBatchEnabledDiag(){
	var checkedVals = new Array();
	$(":checkbox[name=deviceNumCHKBOX][checked]").each(function(){
		checkedVals.push($(this).val());
	});
	if(checkedVals.length < 1){
		alert("请选择需要启用的设备.");
		return;
	}

	// 显示需要处理的设备id列表
	var devBatchHandleListContent = "";
	var selectRows = $("#list").jqGrid('getGridParam','selarrrow');  // 取出已选择的行
	$.each(selectRows, function (index, rowId) {
		var rowData = $("#list").jqGrid('getRowData', rowId);
		if (rowData != null) {
			var deviceStatus = rowData["deviceStatus"];
			if (deviceStatus == "停用") {
				devBatchHandleListContent += "<option value='"+rowData["autoID"] +"'>"+rowData["deviceNum"]+"</option>";
			} else {
				alert("设备编号为：" + rowData["deviceNum"] + ", 该状态下不可启用!");
			}
		}
	});
	if (devBatchHandleListContent == "") {
		return;
	}
	$("#devBatchEnableHandleDevNumsItem").html(devBatchHandleListContent);

	$("#sealBatchEnabledDeviceSidItem").val(checkedVals);
	$("#devBatchEnabledDLG").dialog("open");
}

var initJGrid = false;
function sealInstallView(deviceNum) {
	var url = top.ctx + "/mechseal/sealinstall/sealInstallConfigAction_listw.action?queryBean.params.eq_deviceNum=" + deviceNum;
	if (initJGrid) {
		$("#sealInstallList").jqGrid('setGridParam', { url : url }).trigger("reloadGrid");
	} else {
		$("#sealInstallList").jqGrid({
			//caption : "印章安装信息列表",
			url : url,
			rowList:[10, 15, 20, 30],
			width : 840,
			height : 260,
			rowNum:15,
			rownumbers : true,
			altRows : true,// 就是隔行用不同的背景色区分开
			colNames : [ "设备编号","印章使用机构", "印章位置", "印章类型", "是否沾印油"],
			colModel : [ {
				name : "deviceNum",
				index : "deviceNum"
			}, {
				name : "orgNo",
				index : "orgNo",
				width : 200,
				formatter:function(value, options, rData){
					return Organization.getOrganizationByOrgNo(value).organizationNameAndNo;
				}
			}, {
				name : "sealNum",
				index : "sealNum",
				width : 80
			},  {
				name : "sealTypeName",
				index : "sealTypeName",
				formatter:function(value, options, rData){
					return value;
				}
			}, {
				name : "hasSealOil",
				index : "hasSealOil",
				formatter:function(value, options, rData){
					return fetchSealOil(value);
				}
			}
			]
		});
		initJGrid = true;
	}
	
	$("#sealInstallInfo").dialog("open");
}

/**
 * 设备编号从Excel文件导入
 * 
 * @returns {Boolean}
 */
function deviceImport() {
	if(null == $.trim($("#file").val()) || "" ==  $.trim($("#file").val())){
		alert("导入数据异常：请选择需要导入的模板文件.");
		return;
	}
	var fileName = $.trim($("#file").val());
	var suffix1 = "xls",suffix2 = "xlsx";
	var falg1 = fileName.substring(fileName.length-suffix1.length)==suffix1;
	var falg2 = fileName.substring(fileName.length-suffix2.length)==suffix2;
	if(falg1|| falg2){//只要有一个满足条件即可
		$("#loading").ajaxStart(function() {//开始上传文件时显示一个图片
			$("#importBtn").attr("disabled",true);//禁用按钮
			$(this).show();
		}).ajaxComplete(function() {//文件上传完成将图片隐藏起来
			$("#importBtn").attr("disabled",false);//启用按钮
			$(this).hide();
		});
		$.ajaxFileUpload({url : ctx+"/mmsfile/sealDeviceImportAction!importSealDevNumsFromExcel.action",
			secureuri : false,
			fileElementId : 'file',
			dataType : 'json',
			success : function(res, status){ //服务器成功响应处理函数
				if(res.result){
					if("success" == res.result){
						$("#list").jqGrid("search", "#search");
						$.success("录入数据成功！");
						$("#importDevice").dialog("close");
					}else{
						alert(res.result);
					}
				}else{
					alert("导入数据异常：文件导入过程异常。");
				}
			},error : function(res, status, e){//服务器响应失败处理函数
				alert("导入数据异常：文件导入过程异常。");
			}
		});
	}else{
		alert("导入数据异常：系统只支持Excel模板文件导入,请选择正确的模板文件.");
		return;
	}
}