var flag;
var sealNoOilArray;
var login_People = null;
var orgMap = new Map();
var rownums = new Array();
/**
 * 初始化页面
 */
$(document).ready(function() {
	initInstallDialog();
	initSealInfoDialog();
	initWaitingDialog();
	initTwoDialog();
	initThreeDialog();
	initFourDialog();
	login_People = top.loginPeopleInfo;
//	initSealUseSelect();
	initGrid();
	$("#organizesid_Item").val(login_People.orgName+"("+login_People.orgNo+")");
	$("#organizesid").val(login_People.orgSid);
	$("#organizesid_ItemThree").val(login_People.orgName+"("+login_People.orgNo+")");
	$("#organizesidThree").val(login_People.orgSid);
	$("#organizesid_ItemFour").val(login_People.orgName+"("+login_People.orgNo+")");
	$("#organizesidFour").val(login_People.orgSid);
	queryData();
	
	$("#apprbtn").bind("click",apprbtn);
	$("#lockbtn").bind("click",lockbtn);
	$("#storbtn").bind("click",storbtn);
	// 新建表单提交数据验证
	$("#maintainForm").validationEngine({
		showOnMouseOver : true,
		validationEventTrigger : "keyup blur",
		promptPosition : "centerRight",
		autoPositionUpdate : true,
		onValidationComplete : function() {
		}
	});
});

function initGrid() {
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	$("#sealInstallList").jqGrid(
			{
				width : pageContentWidth,
				height : tableHeight + "px",
				url : ctx + "/mechseal/sealinstall/maintainSealInfoAction_list.action",
				multiselect : false,
				rowNum : 20,
				rownumbers : true,
				viewrecords : true,
				rowList : [ 20, 50, 100 ],
				colNames : [ "印控机编号","章槽号","印章所属机构", "印章种类","印章类型", "印章名称", "维护时间", "章面字样","印章审批人","印章保管人","印章状态","电子锁权限", "操作" ],
				colModel : [
						{
							name : "deviceNum",
							index : "deviceNum",
							// width : 126,
							align : "center",
							sortable : false
						},
						{
							name : "sealNum",
							index : "sealNum",
							// width : 126,
							align : "center",
							sortable : false
						},
						{
							name : "sealOrgNo",
							index : "sealOrgNo",
							// width : 126,
							align : "center",
							sortable : false,
							formatter : function(value, options, rData) {
								var name = queryOrgByOrgSid(value);
								if(name != null) {
									return name;
								} else {
									return "";
								}
							}
						},
						{
							name : "sealGroup",
							index : "sealGroup",
							// width : 126,
							align : "center",
							sortable : false
						},
						{
							name : "sealTypeName",
							index : "sealTypeName",
							// width : 126,
							align : "center",
							sortable : false
						},
						{
							name : "sealName",
							index : "sealName",
							// width : 126,
							align : "center",
							sortable : false
						},
						{
							name : "maintainTime",
							index : "maintainTime",
							 width : 216,
							align : "center",
							sortable : false
						},
						{
							name : "faceFont",
							index : "faceFont",
							// width : 126,
							align : "center",
							sortable : false
						},
						{
							name : "sealApprovalPeopleName",
							index : "sealApprovalPeopleName",
							width : 186,
							align : "center",
							sortable : false/*,
							formatter : function(value, options, rData) {
								if(value != null){
									var name = queryPeopleBySid(value);
									if(name != null) {
										return name;
									}
								}else {
									return "";
								}
							}*/
						},
						{
							name : "sealStoragePeopleName",
							index : "sealStoragePeopleName",
							// width : 126,
							align : "center",
							sortable : false/*,
							formatter : function(value, options, rData) {
								if(value != null){
									var name = queryPeopleBySid(value);
									if(name != null) {
										return name;
									}
								}else {
									return "";
								}
							}*/
						},
						{
							name : "sealStutas",
							index : "sealStutas",
//							width : 126,
							align : "center",
							sortable : false,
							formatter : function(value, options, rData) {
								var name = sealstateList[value];
								if(name != null) {
									return name;
								} else {
									return "";
								}
							}
						},
						{
							name : "eleLockPeopleName",
							index : "eleLockPeopleName",
							width : 186,
							align : "center",
							sortable : false/*,
							formatter : function(value, options, rData) {
								if(value != null){
									var name = queryPeopleBySid(value);
									if(name != null) {
										return name;
									}
								}else {
									return "";
								}
							}*/
						},
						{
							name : "autoId",
							index : "autoId",
							// width : 169,
							align : "center",
							sortable : false,
							formatter : function(value, options, rData) {
								var opt = "";
								if(rData.sealStutas!=2){
									opt = "<button onClick=\"updateInstallSeal('"+value+"');return false;\">修改</button>"
									+ "<button onClick=\"findSeal('"+value+"');return false;\">查看</button>"
								}else{
									opt = "<button onClick=\"findSeal('"+value+"');return false;\">查看</button>"
								}
								return opt;
							}
						} ],
				pager : $("#sealInstallPager"),
				caption : "印章维护信息查询"
			}).trigger("reloadGrid");
	$("#sealInstallList").navGrid("#sealInstallPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};

/**
 * 待修改印章查询
 */
function updateInstallSeal(id) {
	var url = ctx + "/mechseal/sealinstall/maintainSealInfoAction_findByAutoId.action";
	var data = tool.ajaxRequest(url, {
		'autoId' : id
	});
	if (data.success) {
		updateMethod(data.response.sealInstallConfig);
	} else {
		show("服务器响应失败：" + data.response);
	}
};

/**
 * 初始化印章种类下拉框
 */
function initSealUseSelect() {
	selectUtils.initSealBizType("sealTypeName", "1");
};

/**
 * 查询
 */
function query() {
	queryData();
	showMessage("");
};
/**
 * 查询数据，执行查询
 */
function queryData() {
	rownums = new Array();
	$("#sealInstallList").jqGrid('search', "#queryForm");
	$("#peopleList").jqGrid('search', "#queryFormTwo");
	$("#peopleListThree").jqGrid('search', "#queryFormThree");
	$("#peopleListFour").jqGrid('search', "#queryFormFour");
};

function initInstallDialog() {
	$("#dialog").dialog({
		autoOpen : false,
		resizable : false,
		width : $(window).width() /3*2,
		modal : true,
		position : {
			at : "center"
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		}
	});
};

function initSealInfoDialog() {
	$("#sealInfoDialog").dialog({
		autoOpen : false,
		resizable : false,
		width : $(window).width() /3*2,
		height : $(window).height() /4*3,
		modal : true,
		position : {
			at : "center"
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		}
	});
};


/**
 * 查看
 */
function findSeal(id) {

	var url = ctx + "/mechseal/sealinstall/maintainSealInfoAction_findByAutoId.action";
	var data = tool.ajaxRequest(url, {
		'autoId' : id
	});
	if (data.success) {
		findMethod(data.response.sealInstallConfig);
	} else {
		show("服务器响应失败：" + data.response);
	}
};


/**
 * 修改
 */
function sealUpdate() {
	/*$("#sealNum").attr("disabled", false);*/
	var param = {
		"autoId":$("#autoId").val(),
		"sealStutas":$("#sealStutas").val(),
		"sealApprovalPeopleName":$("#sealApprovalPeopleName").val(),
		"sealApprovalPeople":$("#sealApprovalPeople").val(),
		"eleLockPeopleName":$("#eleLockPeopleName").val(),
		"eleLockPeople":$("#eleLockPeople").val(),
		"guangSeal":$("#guangSeal").val(),
		"sealStoragePeopleName":$("#sealStoragePeopleName").val(),
		"sealStoragePeople":$("#sealStoragePeople").val(),
		"memo":$("#memo").val()
	};
	var url = ctx + "/mechseal/sealinstall/maintainSealInfoAction_update.action";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		if (data.response.responseMessage.success) {
			queryData();
			$("#dialog").dialog("close");
			showMessage1(data.response.responseMessage.data);
			showMessage1("");
		} else {
			showMessage1(data.response.responseMessage.message);
		}
	} else {
		show("服务器响应失败：" + data.response);
	}
};


function initInstallForm() {
	$("#orgNo").val(login_People.orgNo);
};

function findMethod(sealInfo) {
	flag = 1;// 1表示查看
	$("#sealInfoDialog").attr("title", "印章维护信息查看");
	$("#sealInfoDialog").dialog("open");
	showMessage1("");
	/*closeInput();*/
	initInstallForm();
	$("#autoIdTwo").val(sealInfo["autoId"]);
	/*$("#orgNo").val(sealInfo["orgNo"]);*/
	$("#sealOrgNoTwo").val(sealInfo["sealOrgNo"]);
	$("#sealOrgNameTwo").val(queryOrgByOrgSid(sealInfo["sealOrgNo"]));
	$("#sealGroupTwo").val(sealInfo["sealGroup"]);
	$("#sealTypeNameTwo").val(sealInfo["sealTypeName"]);
	$("#sealNameTwo").val(sealInfo["sealName"]);
	var ss =sealInfo.guangSeal;
	guangSeal(ss);	
	$("#faceFontTwo").val(sealInfo["faceFont"]);
	$("#sealApprovalPeopleNameTwo").val(sealInfo["sealApprovalPeopleName"]);
	$("#sealApprovalPeople").val(sealInfo["sealApprovalPeople"]);
	var ss =sealInfo.sealStutas;
	sealStutas(ss);
	$("#eleLockPeopleNameTwo").val(sealInfo["eleLockPeopleName"]);
	$("#eleLockPeople").val(sealInfo["eleLockPeople"]);
	$("#sealStoragePeopleNameTwo").val(sealInfo["sealStoragePeopleName"]);
	$("#sealStoragePeople").val(sealInfo["sealStoragePeople"]);
	$("#memoTwo").val(sealInfo["memo"]);
};

function updateMethod(sealInfo) {
	flag = 2;// 2表示修改
	$("#dialog").attr("title", "印章维护信息修改");
	$("#dialog").dialog("open");
	showMessage1("");
	/*closeInput();*/
	initInstallForm();
	$("#autoId").val(sealInfo["autoId"]);
	/*$("#orgNo").val(sealInfo["orgNo"]);*/
	$("#sealOrgNo").val(sealInfo["sealOrgNo"]);
	$("#sealOrgName").val(queryOrgByOrgSid(sealInfo["sealOrgNo"]));
	$("#sealGroup").val(sealInfo["sealGroup"]);
	$("#sealTypeName").val(sealInfo["sealTypeName"]);
	$("#sealName").val(sealInfo["sealName"]);
	var ss =sealInfo.guangSeal;
	guangSeal(ss);
	$("#faceFont").val(sealInfo["faceFont"]);
	$("#sealApprovalPeopleName").val(sealInfo["sealApprovalPeopleName"]);
	$("#sealApprovalPeople").val(sealInfo["sealApprovalPeople"]);
	var ss =sealInfo.sealStutas;
	sealStutas(ss);
	$("#eleLockPeopleName").val(sealInfo["eleLockPeopleName"]);
	$("#eleLockPeople").val(sealInfo["eleLockPeople"]);
	$("#sealStoragePeopleName").val(sealInfo["sealStoragePeopleName"]);
	$("#sealStoragePeople").val(sealInfo["sealStoragePeople"]);
	$("#memo").val(sealInfo["memo"]);
};

function confirmMethod() {
//	 验证表单
	if (!$("#maintainForm").validationEngine("validate")) {
		return;
	}
	var ownerOrg = $("#sealOrgNo").val();
	if(typeof(ownerOrg) == "undefined" || ownerOrg == null || ownerOrg == "" ){
		showMessage1("印章所属机构不能为空！");
		return;
	}

	if (flag == 2) {
		sealUpdate();
	}
};

/**
 * 取消按钮
 */
function cancelMethod() {
	$("#dialog").dialog("close");
	// $("#dialog").reset();
	// 重置dialog内form表单数据
	showMessage1("");
	openBtn();
};

/**
 * 显示提示信息
 * 
 * @param message
 *            信息
 */
function showMessage(message) {
	$("#showMessage").text(message);

};

function showMessage1(message) {
	$("#showMessage1").text(message);

};

function show(msg) {
	// 暂时未使用jquery的alert
	alert(msg);
};
/**
 * 取消按钮
 */
function closeBtn() {
	$("#dialogTwo").dialog("close");
	$("#dialogThree").dialog("close");
	$("#dialogFour").dialog("close");
	$("#peopleName").val("");
	$("#peopleCode").val("");
	$("#peopleNameThree").val("");
	$("#peopleCodeThree").val("");
	$("#peopleNameFour").val("");
	$("#peopleCodeFour").val("");
	queryData();
	showMessage1("");
};

function openBtn() {
	$("#confirmBtn").attr("disabled", false);
};

function initWaitingDialog() {
	$("#waitingDialog").dialog({
		autoOpen : false,
		resizable : false,
		draggable : false,
		closeOnEscape : false,
		height : 290,
		width : 390,
		modal : true,
		open : function(event, ui) {
			$(".ui-dialog-titlebar").hide();
			$(".ui-dialog-titlebar-close").hide();
		}
	});
}

/**
 * 展示等待界面
 */
function showWaitingDialog(msg) {
	$("#waitingDialog").dialog("open");
	$("#waitingMsg").html(msg);
}

/**
 * 关闭等待界面
 */
function hideWaitingDialog() {
	$("#waitingDialog").dialog("close");
}

/**
 * 页面关闭响应事件
 */
function closePage() {
	ocxbase_sealMachine.closeMachine();
};

/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo){
//	var organizationSid = "00000000000000000000000000000000";
	var organizationSid = top.loginPeopleInfo.orgSid;
	$("#organizesid_Item").dialogOrgTree("radio", organizationSid, false, null,null, function(event, treeId, treeNode){
		if(treeNode){
			$("#"+organizationNo+"_Item").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
			$("#"+organizationNo).val(treeNode.sid);
		}
	});
}
function checkOrganizationItemThree(organizationNo){
	var organizationSid = top.loginPeopleInfo.orgSid;
//	var organizationSid = "00000000000000000000000000000000";
	$("#organizesid_ItemThree").dialogOrgTree("radio", organizationSid, false, null,null, function(event, treeId, treeNode){
		if(treeNode){
			$("#organizesid_ItemThree").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
			$("#organizesidThree").val(treeNode.sid);
		}
	});
}
function checkOrganizationItemFour(organizationNo){
	var organizationSid = top.loginPeopleInfo.orgSid;
//	var organizationSid = "00000000000000000000000000000000";
	$("#organizesid_ItemFour").dialogOrgTree("radio", organizationSid, false, null,null, function(event, treeId, treeNode){
		if(treeNode){
			$("#organizesid_ItemFour").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
			$("#organizesidFour").val(treeNode.sid);
		}
	});
}


function queryOrgByOrgSid(value) {
	var url = ctx
	+ "/ext/po/extOrganizationAction_findOrganizationByOrganizationNo.action";
	var param = {"orgNo":value}
	var result = tool.ajaxRequest(url, param);
	if(result.success) {
		return result.response.organization.organizationName+"("+result.response.organization.organizationNo+")"
	} else {
		return null;
	}
}

function queryPeopleBySid(value) {
	var url = ctx
	+ "/ext/po/extPersonnelAction_findFormatPersonnelByPersonnelSid.action";
	var param = {"personnelSid":value}
	var result = tool.ajaxRequest(url, param);
	if(result.success) {
		return result.response.personnel.personnelName;
	} else {
		return null;
	}
}

/*function queryOrgBySealType(value) {
	var url = ctx
	+ "/ext/po/extOrganizationAction_findOrganizationByOrganizationNo.action";
	var param = {"sealType":value}
	var result = tool.ajaxRequest(url, param);
	if(result.success) {
		return result.response.organization.organizationName+"("+result.response.organization.organizationNo+")"
	} else {
		return null;
	}
}*/



function addBtn(){
	var selectedId = $("#peopleList").jqGrid('getGridParam','selarrrow');  // 取出已选择的行
	if(null == selectedId || selectedId.length== 0){
		alert("请选择审批人");
		return;
	}else{
		for(var i=0;i<selectedId.length;i++ ) {
			var rowDatas= jQuery("#peopleList").jqGrid('getRowData',selectedId[i]);
			var flag = true;
			if(selectList.length > 0) {
				for(var k = 0; k < selectList.length; k ++) {
					if(rowDatas.sid == selectList[k]) {
						flag = false;
					}
				}
			}
			if(flag) {		
				var data = { sid:rowDatas.sid,  peopleName:rowDatas.peopleName, peopleCode:rowDatas.peopleCode, orgName:rowDatas.orgName};		
				$("#peopleListsp").jqGrid('addRowData', rowDatas.sid, data, 'first');
				selectList.push(rowDatas.sid);
				selectListName.push(rowDatas.peopleName);
			}else{
				alert("有重复人员："+rowDatas.peopleName);
			}
		}

	}
}
function delBtn(){
	
	var sealinstallid = $("#autoId").val();
	var selectedId = $("#peopleListsp").jqGrid("getGridParam","selarrrow"); 
    if(!selectedId){
	     　　alert("请选择要删除的行");
	     　　return;
    }else{
    	var count = selectedId.length;
    	var myArray=new Array();
    	var j=0;
    	for(var i=0;i<count;i++ ) {
    		var rowDatas= jQuery("#peopleListsp").jqGrid('getRowData',selectedId[i]);
    		var url =ctx + "/mechseal/sealinstall/maintainSealInfoAction_checkTransferPower.action";
    		var param = {"sealApprovalPeople":rowDatas.sid,
    				"sealinstallid":sealinstallid
    		}
    		var result = tool.ajaxRequest(url, param);
    		if (result.success && result.response.responseMessage.success){
    		}else{
    			alert(rowDatas.peopleName+"存在转授权");
    			return;
    		}
    		myArray[j]=selectedId[i];
    		j++;	
    	}

    	var countj = myArray.length;
    	for(var i=0;i<countj;i++ ) {
    		var rowDatas= jQuery("#peopleListsp").jqGrid('getRowData',myArray[i]);
    		var index = selectList.indexOf(rowDatas.sid);
			if (index > -1) {
				selectList.splice(index, 1);
				selectListName.splice(index, 1);
				$("#peopleListsp").jqGrid("delRowData", myArray[i]); 
			}
    	}
    }
}

function initPeople() {
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 100;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	$("#peopleList").jqGrid(
			{
				width : pageContentWidth,
				height : tableHeight + "px",
				url : ctx + "/mechseal/sealinstall/maintainSealInfoAction_queryPeopleByRole.action?queryType=apprbtn",
				rowNum : 1000,
				rownumbers : true,
				viewrecords : true,
				multiselect: true,
				colNames : ["","用户姓名", "用户代码","所属机构"/*, "角色"*/],
				colModel : [
						{
							name : "sid",
							index : "sid",
							align : "center",
							sortable : false,
							hidden:true,
							formatter : function(value, options, rData) {
								var sealApprovalPeople = $("#sealApprovalPeople").val();
								var sealApprovalPeoples = "";
								if(sealApprovalPeople != "" && sealApprovalPeople != null) {
									sealApprovalPeoples = sealApprovalPeople.split(","); 
									for(var i = 0; i < sealApprovalPeoples.length; i ++) {
										if(sealApprovalPeoples[i] == value) {
											var rowNum = options.rowId;
											rownums.push(rowNum);
										}
									}
								}
								return value;
							}
						},
						{
							name : "peopleName",
							index : "peopleName",
							align : "center",
							sortable : true
						},
						{
							name : "peopleCode",
							index : "peopleCode",
							align : "center",
							sortable : false
						},
						{
							name : "orgName",
							index : "orgName",
							// width : 126,
							align : "center",
							sortable : false
						}
						],
				pager : $("#peoplePager"),
//				loadonce:true,
//				sortable:true,
//				sortname:'peopleName',
//				sortorder:'desc',
				caption : "人员信息查询"
			}).trigger("reloadGrid");
	$("#peopleList").navGrid("#peoplePager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});	
	
	$("#peopleListsp").jqGrid(
			{
				width : pageContentWidth,
				height : tableHeight + "px",
				url : ctx + "/mechseal/sealinstall/maintainSealInfoAction_findBySPRolelist.action?sealApprovalPeople="+$("#sealApprovalPeople").val(),
				rowNum : 1000,
				rownumbers : true,
				viewrecords : true,
				multiselect: true,
//				postData : {
//					"sealApprovalPeople" : sealapproval
//				},
//				multiboxonly:true,
				rowList : [ 20, 50, 100 ],
//				loadComplete:function() {
//					for(var i = 0; i < rownums.length; i ++) {
//						$("#peopleList").jqGrid('setSelection', rownums[i]);
//					}
//				},
				colNames : ["","用户姓名", "用户代码","所属机构"],
				colModel : [
						{
							name : "sid",
							index : "sid",
							align : "center",
							sortable : false,
							hidden:true
//							,
//							formatter : function(value, options, rData) {
//								var sealApprovalPeople = $("#sealApprovalPeople").val();
//								var sealApprovalPeoples = "";
//								if(sealApprovalPeople != "" && sealApprovalPeople != null) {
//									sealApprovalPeoples = sealApprovalPeople.split(","); 
//									for(var i = 0; i < sealApprovalPeoples.length; i ++) {
//										if(sealApprovalPeoples[i] == value) {
//											var rowNum = options.rowId;
//											rownums.push(rowNum);
//										}
//									}
//								}
//								return value;
//							}
						},
						{
							name : "peopleName",
							index : "peopleName",
							align : "center",
							sortable : false
						},
						{
							name : "peopleCode",
							index : "peopleCode",
							align : "center",
							sortable : false
						},
						{
							name : "orgName",
							index : "orgName",
							// width : 126,
							align : "center",
							sortable : false
						}
						],
				pager : $("#peoplePagersp"),
				caption : "审批人员信息"
			}).trigger("reloadGrid");
	$("#peopleListsp").navGrid("#peoplePagersp", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};


function initPeopleThree() {
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 100;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	$("#peopleListThree").jqGrid(
			{
				width : pageContentWidth,
				height : tableHeight + "px",
				url : ctx + "/mechseal/sealinstall/maintainSealInfoAction_queryPeopleByRole.action?queryType=lockbtn",
				rowNum : 100,
				rownumbers : true,
				viewrecords : true,
				multiselect: true,
				multiboxonly:true,
				beforeSelectRow: beforeSelectRow,
				loadComplete:function() {
					for(var i = 0; i < rownums.length; i ++) {
						$("#peopleListThree").jqGrid('setSelection', rownums[i]);
					}
				},
				rowList : [ 20, 50, 100 ],
				colNames : [ "","用户姓名", "用户代码","所属机构"],
				colModel : [
						{
							name : "sid",
							index : "sid",
							align : "center",
							sortable : false,
							hidden:true,
							formatter : function(value, options, rData) {
								var eleLockPeople = $("#eleLockPeople").val();
								var eleLockPeoples = "";
								if(eleLockPeople != "" && eleLockPeople != null) {
									eleLockPeoples = eleLockPeople.split(","); 
									for(var i = 0; i < eleLockPeoples.length; i ++) {
										if(eleLockPeoples[i] == value) {
											var rowNum = options.rowId;
											rownums.push(rowNum);
										}
									}
								}
								return value;
							}
						},
						{
							name : "peopleName",
							index : "peopleName",
							align : "center",
							sortable : false
						},
						{
							name : "peopleCode",
							index : "peopleCode",
							align : "center",
							sortable : false
						},
						{
							name : "orgName",
							index : "orgName",
							// width : 126,
							align : "center",
							sortable : false
						}
						],
				pager : $("#peoplePagerThree"),
				caption : "电子锁权限人员信息查询"
			}).trigger("reloadGrid");
	$("#peopleListThree").navGrid("#peoplePagerThree", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};



function initPeopleFour() {	
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 100;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	$("#peopleListFour").jqGrid(
			{
				width : pageContentWidth,
				height : tableHeight + "px",
				url : ctx + "/mechseal/sealinstall/maintainSealInfoAction_queryPeopleByRole.action?queryType=storbtn",
				multiselect : false,
				rowNum : 100,
				rownumbers : true,
				viewrecords : true,
				multiselect: true,
				loadComplete:function() {
					for(var i = 0; i < rownums.length; i ++) {
						$("#peopleListFour").jqGrid('setSelection', rownums[i]);
					}
				},
				rowList : [ 20, 50, 100 ],
				colNames : [ "","用户姓名", "用户代码","所属机构"],
				colModel : [
						{
							name : "sid",
							index : "sid",
							align : "center",
							sortable : false,
							hidden:true,
							formatter : function(value, options, rData) {
								var sealStoragePeople = $("#sealStoragePeople").val();
								var sealStoragePeoples = "";
								if(sealStoragePeople != "" && sealStoragePeople != null) {
									sealStoragePeoples = sealStoragePeople.split(","); 
									for(var i = 0; i < sealStoragePeoples.length; i ++) {
										if(sealStoragePeoples[i] == value) {
											var rowNum = options.rowId;
											rownums.push(rowNum);
										}
									}
								}
								return value;
							}
						},
						{
							name : "peopleName",
							index : "peopleName",
							align : "center",
							sortable : false
						},
						{
							name : "peopleCode",
							index : "peopleCode",
							align : "center",
							sortable : false
						},
						{
							name : "orgName",
							index : "orgName",
							// width : 126,
							align : "center",
							sortable : false
						}
						],
				pager : $("#peoplePagerFour"),
				caption : "印章保管人员信息查询"
			}).trigger("reloadGrid");
	$("#peopleListFour").navGrid("#peoplePagerFour", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};




function findRoleGroup(sid) {
	var url =ctx + "/mechseal/sealinstall/maintainSealInfoAction_findRoleGroup.action";
	var param = {"sid":sid}
	var result = tool.ajaxRequest(url, param);
	if(result.success) {
		return result.response.responseMessage.data;
	} else {
		return null;
	}
}
 function initTwoDialog() {
	$("#dialogTwo").dialog({
		autoOpen : false,
		resizable : false,
		height : $(window).height(),
		width : $(window).width()/9*8,
		modal : true,
		position : {
			at : "center"
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		},
		close: function(event, ui) {
			$("#organizesid_Item").val(login_People.orgName+"("+login_People.orgNo+")");
			$("#organizesid").val(login_People.orgSid);
			$("#organizesid_ItemThree").val(login_People.orgName+"("+login_People.orgNo+")");
			$("#organizesidThree").val(login_People.orgSid);
			$("#organizesid_ItemFour").val(login_People.orgName+"("+login_People.orgNo+")");
			$("#organizesidFour").val(login_People.orgSid);
		}
	});
};

function initThreeDialog() {
	$("#dialogThree").dialog({
		autoOpen : false,
		resizable : false,
		height : $(window).height(),
		width : $(window).width()/9*8,
		modal : true,
		position : {
			at : "center"
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		},
		close: function(event, ui) {
			$("#organizesid_Item").val(login_People.orgName+"("+login_People.orgNo+")");
			$("#organizesid").val(login_People.orgSid);
			$("#organizesid_ItemThree").val(login_People.orgName+"("+login_People.orgNo+")");
			$("#organizesidThree").val(login_People.orgSid);
			$("#organizesid_ItemFour").val(login_People.orgName+"("+login_People.orgNo+")");
			$("#organizesidFour").val(login_People.orgSid);
		}
	});
};

function initFourDialog() {
	$("#dialogFour").dialog({
		autoOpen : false,
		resizable : false,
		height : $(window).height(),
		width : $(window).width()/9*8,
		modal : true,
		position : {
			at : "center"
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		},
		close: function(event, ui) {
			$("#organizesid_Item").val(login_People.orgName+"("+login_People.orgNo+")");
			$("#organizesid").val(login_People.orgSid);
			$("#organizesid_ItemThree").val(login_People.orgName+"("+login_People.orgNo+")");
			$("#organizesidThree").val(login_People.orgSid);
			$("#organizesid_ItemFour").val(login_People.orgName+"("+login_People.orgNo+")");
			$("#organizesidFour").val(login_People.orgSid);
		}
	});
};


function apprbtn() {
	$("#dialogTwo").dialog("open");
	rownums = new Array();
	initPeople();
	
	selectList = new Array();
	selectListName = new Array();
	var sealApprovalPeople = $("#sealApprovalPeople").val();
	
	$("#peopleListsp").jqGrid("clearGridData");
	var sealinstallid = $("#autoId").val();
	var url =ctx + "/mechseal/sealinstall/maintainSealInfoAction_findBySPRole.action";
	var param = {"sealApprovalPeople":sealApprovalPeople,
			"sealinstallid":sealinstallid
			}
	var result = tool.ajaxRequest(url, param);
	if(result.success) {
		var data = result.response.responseMessage.data;
		for ( var i = 0; i < data.length; i++) {
			var sid = data[i].sid;
			var peopleName = data[i].peopleName;
			selectList.push(sid);
	    	selectListName.push(peopleName);
		}
		
	}
		
};

function lockbtn() {
	$("#dialogThree").dialog("open");
	rownums = new Array();
	initPeopleThree();

};

function storbtn() {
	$("#dialogFour").dialog("open");
	rownums = new Array();
	initPeopleFour();

};


function queryByOrgSid(value) {
	var url = ctx
	+ "/ext/po/extOrganizationAction_findOrganizationByOrganizationSid.action";
	var param = {"sid":value}
	var result = tool.ajaxRequest(url, param);
	if(result.success) {
		return result.response.organization.organizationName;
	} else {
		return null;
	}
}

function queryByOrgNo(value) {
	var url = ctx
	+ "/mechseal/sealinstall/maintainSealInfoAction_findOne.action";
	var param = {"sid":value}
	var result = tool.ajaxRequest(url, param);
	if(result.success) {
		return result.response.organization.organizationName;
	} else {
		return null;
	}
}
/*function queryOrg() {
	var sid=login_People.orgSid;
	$.post(ctx + "/ext/po/extOrganizationAction_findParentOrganizationByOrganizationSid.action",
			{
				"sid" : sid,
			},
			function(data){
				if(null != data.responseMessage){
					if(data.responseMessage.success){
						$("#organizesid_Item").val(login_People.orgName+"("+login_People.orgNo+")");
						$("#organizesid").val(login_People.orgSid);
					}else{
						alert(data.responseMessage.message);
					}
				}else{
					alert("服务异常");
				}
	});
}*/


function initSelectRow() {
	var ids = $("#peopleList").jqGrid('getGridParam','selarrrow');  // 取出已选择的行
	if(null == ids || ids.length== 0){
		alert("请选择审批人");
		return;
	}else{
		for(var i=0;i<ids.length;i++ ) {
			var rowDatas= jQuery("#peopleList").jqGrid('getRowData',ids[i]);
			var flag = true;
			if(selectList.length > 0) {
				for(var k = 0; k < selectList.length; k ++) {
					if(rowDatas.sid == selectList[k]) {
						flag = false;
					}
				}
			}
			if(flag) {
				tmp=tmp+rowDatas.peopleName+",";
				tmv=tmv+rowDatas.sid+",";
				html += "<tr index='"+rowDatas.sid+"'><td style='width: 300px'>" + rowDatas.peopleName + "</td><td style='width: 300px'>" + rowDatas.peopleCode + "</td><td style='width: 300px'>" + rowDatas.orgName + "</td>" +
						"<td><input  type='button' value='删除' onclick='deleteSelect('"+rowDatas.sid+"');return false;' class='ui-button ui-widget ui-state-default ui-corner-all' /></td></tr>";
				selectList.push(rowDatas.sid);
			}
		}
		$("#sealContentIterm").html(html);
		tmp=tmp.substring(0,tmp.length-1);
		tmv=tmv.substring(0,tmv.length-1);
	}
}

function deleteSelect(sid) {
	
}

function commitDate(){

	var tmp="";
	var tmv="";
	
	for(var i = 0; i < selectListName.length; i ++) {
		tmp = tmp + selectListName[i] + ",";
	}
	for(var i = 0; i < selectList.length; i ++) {
		tmv = tmv + selectList[i] + ",";
	}
	
	if(tmp==""){
		alert("请选择审批人");
		return;
	}
	
	tmp=tmp.substring(0,tmp.length-1);
	tmv=tmv.substring(0,tmv.length-1);
	
	var str=tmp;
	var len=str.length;
//	if(len>1000){
//		alert("审批人最大字符不大于1000,请重新选择");
//		return false;
//	}
	
	if(selectListName.length>100){
		alert("审批人人不能大于100个,请重新选择！");
		return false;
	}
	
	var url =ctx + "/mechseal/sealinstall/maintainSealInfoAction_saveBySPRole.action";
	var param = {"sealApprovalPeople":tmv,"sealApprovalPeopleName":tmp}
	var result = tool.ajaxRequest(url, param);
	if(result.success) {
		$("#sealApprovalPeopleName").val(tmp);
		$("#sealApprovalPeople").val(tmv);
		$("#dialogTwo").dialog("close");	
	}else{
		alert("保存失败");
	}	
}


function commitDateThree(){
	var rowid=$("#peopleListThree").jqGrid("getGridParam","selrow"); 
	var rowData=jQuery("#peopleListThree").jqGrid("getRowData",rowid);
	$("#eleLockPeopleName").val(rowData.peopleName);
	$("#eleLockPeople").val(rowData.sid);
	$("#dialogThree").dialog("close");
}
function commitDateFour(){
	var ids = $("#peopleListFour").jqGrid('getGridParam','selarrrow');  // 取出已选择的行
	var tmp="";
	var tmv="";
	if(null == ids || ids.length== 0){
		alert("请选择印章保管人");
		return;
	}else{
		for(var i=0;i<ids.length;i++ ) {
			var rowDatas= jQuery("#peopleListFour").jqGrid('getRowData',ids[i]);
			tmp=tmp+rowDatas.peopleName+",";
			tmv=tmv+rowDatas.sid+",";
		}
		tmp=tmp.substring(0,tmp.length-1);
		tmv=tmv.substring(0,tmv.length-1);
	}
	var str=tmp;
	var len=str.length;
	if(len>120){
		alert("保管人最大字符不大于120,请重新选择");
		return false;
	}
	$("#sealStoragePeopleName").val(tmp);
	$("#sealStoragePeople").val(tmv);
	
	$("#dialogFour").dialog("close");
	
}

function beforeSelectRow()
{
    var s;
    s = $("#peopleListThree").jqGrid('getGridParam', 'selrow'); //获取最后选择行的id
    $("#peopleListThree").jqGrid('setSelection', s);
    $("#peopleListThree").jqGrid('resetSelection');
    return(true);
}


/**
 * 印章状态
 */
var sealstateList = {
	    "0" : "启用",
	    "1" : "停用",
	    "2" : "销毁"
};



function sealStutas(value){
	if(value == 0){
		$("#sealStutas").val("启用");
		$("#sealStutasTwo").val("启用");
		$("#sealStutasA").attr("selected", "selected");
	}else if(value == 1){
		$("#sealStutas").val("停用");
		$("#sealStutasTwo").val("停用");
		$("#sealStutasB").attr("selected", "selected");
	}else if(value == 2){
		$("#sealStutas").val("销毁");
		$("#sealStutasTwo").val("销毁");
		$("#sealStutasC").attr("selected", "selected");
	}else{
		$("#sealStutasD").attr("selected", "selected");
	}
}

function guangSeal(value){
	if(value == 0){
		$("#guangSeal").val("是");
		$("#guangSealTwo").val("是");
		$("#guangSealA").attr("selected", "selected");
	}else{
		$("#guangSeal").val("否");
		$("#guangSealTwo").val("否");
		$("#guangSealB").attr("selected", "selected");
	}
}

function length(str){
	var len = 0;
	var lenth=str.split(',').length-1;
    for (var i=0; i<str.length - lenth; i++) { 
    	//汉字加2 
    	if(/.*[\u4e00-\u9fa5]+.*$/.test(str)) {
    		len+=2;
    	}
    } 
    len +=lenth;
    return len;
}



