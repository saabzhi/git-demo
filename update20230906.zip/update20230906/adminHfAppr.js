var roleGroupMap = new Map();
var scanNum = null;
var hasFile = false;
var loginPeople = null;
var filePath1 = null;
var listId = null;
/**
 * 页面初始化加载
 */
$(document).ready(function() {
	initUseSealPage();
	initTaskList();
	initOrgNo();
	initSealType();
});
var sealUseConstant = new Object();
sealUseConstants.SealUseApplyStatus = {
	"0" : "等待提交(Pending Submission)",
	"1" : "等待审批(Pending Approval)",
	"2" : "审批通过(Approved)",
	"3" : "审批拒绝(Rejected)"
};

function initSealType(){
	var params = {
			
	};
	$.post(ctx+"/report/takeRetuenSealReportAction_findSealType.action",params,function(data){
		if(data.responseMessage.success){
			var sealTypeMap=data.sealMap;
			var sealTypeContent = "<option value=' '>全部</option>";
			for ( var key in sealTypeMap) {
				sealTypeContent += "<option value='" + key + "'>" + sealTypeMap[key] + "</option>";
			}
			$("#sealType").html(sealTypeContent);
			
		}else{
			alert(res.responseMessage.message);
		}
	});
	
}


/**
 * 页面初始化加载
 */
$(function() {
	var options = {
		type : 'POST',
		url : ctx
				+ "/sealusetask/create/sealUsehfTask_createApproveSealTask.action",
		success : showResponse,
		error : function(xhr, status, err) {
			alert("操作失败");
		}
	};
	$("#sealUseApplyForm").submit(function() {
		$(this).ajaxSubmit(options);
		return false; // 防止表单自动提交
	});

});
function showResponse(data, status) {
	data = data.substring("0", data.indexOf("}")+1);
	data = jQuery.parseJSON(data);
	if (data.result == 'success') {
		alert("操作成功Done");
		$("#useSealList").jqGrid("resetSelection");
		$("#sealUseApplyForm")[0].reset();
		$("#sealUseApplyForm1")[0].reset();
		$("#sealUseTaskInfo").dialog("close");
		location.reload();
	}
};

/**
 * 初始化任务列表
 */
function initTaskList() {
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight
			+ 6 - 50 * 2;
	var url = ctx
			+ "/mechseal/task/sealUseApprTaskHfAction_gainTaskList.action?_t="+ _t;
	// 用印信息列表
	$("#useSealList")
			.jqGrid(
					{
						width : pageContentWidth,
						height : tableHeight + "px",
						url : url,
						multiselect : false,
						rowNum : 20,
						rownumbers : true,
						sortable : true,// 是否排序
						sortname : "applyDate",
						sortorder : "desc",
						multiselect : true,
						rowList : [ 20, 50, 100 ],// "印章类型", "印章所属机构", "印章名称",
						colNames : [ "流水号(Serial Number)", "申请机构名称(Applicant: Affiliated Institution)", "申请人(Applicant)", 
									 "申请时间(Application Date)", "审批人(Authorizer)","审批时间(Chop Authorization Date)",
						             "印章类型(Chop Type)", "印章名称(Chop Name)","文件名称(File Name)","用印原因(Chop Using Reason)", "申请审批状态(Chop Applying and Authorizing Status)", "操作(Action)" ],
						colModel : [
								{
									name : "tradeCode",
									index : "tradeCode",
									align : "center",
									width : 100,
									sortable : false
								},
								{
									name : "applyPeopleOrgName",
									index : "applyPeopleOrgName",
									align : "center",
									width : 200,
									sortable : false
								},
								{
									name : "peopleName",
									index : "peopleName",
									align : "center",
									width : 160,
									sortable : false
								},
								{
									name : "applyTime",
									index : "applyTime",
									align : "center",
									width : 160,
									sortable : false
								},
								{
									name : "nextHandlerName",
									index : "nextHandlerName",
									align : "center",
									width : 160,
									sortable : false
								},
								{
									name : "checkTime",
									index : "checkTime",
									align : "center",
									width : 160,
									sortable : false
								},
								
						
								 { 
									name : "sealTypeName", 
									index : "sealTypeName",
									align : "center",
									width : 160,
									sortable : false 
								 }, 
								 { 
									 name :"title", 
									 index : "title", 
									 align :"center", 
									 width : 100,
									 sortable : false 
								 },
								 
								
								/*
								 * { name : "sealType", index : "sealType",
								 * align : "center", sortable : false }, { name :
								 * "sealOrgName", index : "sealOrgName", align :
								 * "center", sortable : false }, { name :
								 * "sealTypeName", index : "sealTypeName", align :
								 * "center", width : 50, sortable : false },
								 */
								{
									name : "applyTitle",
									index : "applyTitle",
									align : "center",
									width : 200,
									sortable : false
								},
								
								{
									name : "useSealReason",
									index : "useSealReason",
									align : "center",
									width : 300,
									sortable : false
								},

								{
									name : "status",
									index : "status",
									align : "center",
									width : 100,
									sortable : false,
									formatter : function(value, options, rData) {
										return sealUseConstants.SealUseApplyStatus[value];
									}
								},

								{
									name : "id",
									index : "id",
									align : "center",
									sortable : false,
									formatter : function(value, options, rData) {
										return "<input type='button' style=\" width:65px;  \" onclick=\"showDetail('"
												+ value + "');\" value='查看(View)' />";

									}
								} ],
						pager : "#useSealPager",
						caption : "审批列表(Approval List) "
					}).trigger("reloadGrid");
	$("#useSealList").navGrid("#useSealPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};
function updateUseSeakTask() {
	
	var ids = $("#useSealList").jqGrid("getGridParam", "selarrrow");
	if (ids.length > 1 || ids.length == 0) {
		alert("请选择单笔任务审批");
		$("#useSealList").jqGrid("resetSelection");
		return;
	}
	var row = $("#useSealList").jqGrid("getRowData", ids[0]);
	if (row.status != "等待审批(Pending Approval)") {
		alert("请选择等待审批任务进行审批");
		$("#useSealList").jqGrid("resetSelection");
		return;
	}
	var id = row.tradeCode;
	$("#sealUseTaskInfo").data("sealUseApplyForm", id).dialog("open");
}
function showDetail(id) {
	$("#sealUseTaskInfo1").data("sealUseApplyForm1", id).dialog("open");
}

function initUseSealPage() {
	$("#submitForm").click(function() {
		queryApplyInfoForTerm();
	});
	$("#clearForm").click(function() {
		$("#queryForm")[0].reset();
	});
	$("#sealUseTaskInfo")
			.dialog(
					{
						autoOpen : false,
						resizable : false,
						width : 650,
						height : 'auto',
						modal : true,
						position : {
							at : "center"
						},

						close : function() {
							initTaskList();
							num = 1;
							$("#queryForm")[0].reset();
							$("#sealUseApplyForm")[0].reset();
							$("#sealUseApplyForm1")[0].reset();
							location.reload();
						},
						open : function() {
							var _this = this;
							var id = $(this).data("sealUseApplyForm");
							if (id) {// 更新
								$.post(ctx+ "/mechseal/task/sealUseApprTaskHfAction_gainUpdateTask.action?_t="+ _t+"23",
												{"bizInfo.id" : id},
												function(data) {
													if (data.responseMessage.success) {
														var mechSealInfos = data.mechSealInfos;
														var mechSealFiles = data.mechSealFiles;
														var bizInfo = data.bizInfo;
														var html = "";
														if (mechSealFiles!= null) {
															hasFile = true;
															document.getElementById("docwordTr").style.display = "";
															for ( var i = 0; i < mechSealFiles.length; i++) {
																var htmls = "<td>"+ mechSealFiles[i].fileDesc+ "</td>";
																html += "<div><td>"+ mechSealFiles[i].fileDesc+ "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ "<a style=\"font-weight:700;\" href='"+ ctx+ "/mechseal/task/FileDownload.action?filePath="+ mechSealFiles[i].originalStore+ "'>下载(download)</a></td></div>";
																filePath1 = mechSealFiles[i].filePath;
															}
															$('#docword1').html(html);
															$("#hasFile").val("1");
															$(_this).fillForm({tableApply : data.tableApply});
															$("#sealUseTaskInfo").dialog("open");
															array= data.tableApply.apprPeople.split(",");
															arrayname= data.tableApply.apprPeopleName.split(",");
															var options = '';
															options+="<option id='people' value=\"\">--请选择--</option>";
															for (var i=0;i<array.length;i++) {
																options += "<option  id='people"+i+"' value=\""+ array[i]+"\">" + arrayname[i] + "</option>";
															}
															
															$(".apprPeopleSid").html(options);
															$(_this).fillForm({tableApply : data.tableApply});
															for (var i=0;i<array.length;i++) {
																if(array[i]==data.tableApply.apprPeopleSid){
																	document.getElementById("people"+i).selected = true;
																}
															}
														} else {
															hasFile = false;
															$("#hasFile").val("1");
															$(_this).fillForm({tableApply : data.tableApply});
															$("#sealUseTaskInfo").dialog("open");
															array= data.tableApply.apprPeople.split(",");
															arrayname= data.tableApply.apprPeopleName.split(",");
															var options = '';
															options+="<option id='people' value=\"\">--请选择--</option>";
															for (var i=0;i<array.length;i++) {
																options += "<option  id='people"+i+"' value=\""+ array[i]+"\">" + arrayname[i] + "</option>";
															}
															
															$(".apprPeopleSid").html(options);
															$(_this).fillForm({tableApply : data.tableApply});
															for (var i=0;i<array.length;i++) {
																if(array[i]==data.tableApply.apprPeopleSid){
																	document.getElementById("people"+i).selected = true;
																}
															}
														}
													} else {
														alert(data.responseMessage.message);
														$("#sealUseApplyForm")[0].reset();
														$("#sealUseApplyForm1")[0].reset();
														$("#sealUseTaskInfo").dialog("close");
													}

												});
							}
						}
					});
	$("#sealUseTaskInfo1")
			.dialog(
					{
						autoOpen : false,
						resizable : false,
						width : 650,
						height : 'auto',
						modal : true,
						position : {
							at : "center"
						},
						close : function() {
							initTaskList();
							$("#sealUseApplyForm1")[0].reset();
							$("#sealUseApplyForm")[0].reset();
							location.reload();
						},
						open : function() {
							var _this = this;
							var id = $(this).data("sealUseApplyForm1");
							if (id) {// 更新
								$.post(ctx+ "/mechseal/task/sealUseApprTaskHfAction_gainUpdateTask.action?_t="+ _t+"23",
												{
													"bizInfo.id" : id
												},
												function(data) {
													if (data.responseMessage.success) {
														var mechSealInfos = data.mechSealInfos;
														var mechSealFiles = data.mechSealFiles;
														var bizInfo = data.bizInfo;
														var filenetautoid =data.filenetautoid;
														var filesynchroStatus =data.filesynchroStatus;
														var html = "";
														if (mechSealFiles!= null) {
															hasFile = true;
															document.getElementById("docwordTr1").style.display = "";
															var html = "";
															
															if(filesynchroStatus!=2){
																for ( var i = 0; i < mechSealFiles.length; i++) {
																	var htmls = "<td>"+ mechSealFiles[i].fileDesc+ "</td>";
																	html += "<div><td>"+ mechSealFiles[i].fileDesc+ "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ "<a style=\"font-weight:700;\" href='"+ ctx+ "/mechseal/task/FileDownload.action?filePath="+ mechSealFiles[i].originalStore+ "'>下载(download)</a></td></div>";
																	filePath1 = mechSealFiles[i].filePath;
																}
															}else{
																var htmls = "<td></td>";
																html += "<div>文件已转存至FILENET,附件流水号:"+id+"0; <span color='red'> 请联系总行/分行系统管理员获取</span> </div>";
															}
															
															$('#docword2').html(html);
															$("#hasFile").val("1");
															$(_this).fillForm({tableApply : data.tableApply});
															$("#sealUseTaskInfo1").dialog("open");
															array= data.tableApply.apprPeople.split(",");
															arrayname= data.tableApply.apprPeopleName.split(",");
															var options = '';
															options+="<option id='people' value=\"\">--请选择--</option>";
															for (var i=0;i<array.length;i++) {
																options += "<option  id='people"+i+"' value=\""+ array[i]+"\">" + arrayname[i] + "</option>";
															}
															
															$("#apprPeopleSid1").html(options);
															$(_this).fillForm({tableApply : data.tableApply});
															for (var i=0;i<array.length;i++) {
																if(array[i]==data.tableApply.apprPeopleSid){
																	document.getElementById("people"+i).selected = true;
																}
															}
														} else {
															hasFile = false;
															$("#hasFile").val("1");
															$(_this).fillForm({tableApply : data.tableApply});
															$("#sealUseTaskInfo1").dialog("open");
															array= data.tableApply.apprPeople.split(",");
															arrayname= data.tableApply.apprPeopleName.split(",");
															var options = '';
															options+="<option id='people' value=\"\">--请选择--</option>";
															for (var i=0;i<array.length;i++) {
																options += "<option  id='people"+i+"' value=\""+ array[i]+"\">" + arrayname[i] + "</option>";
															}
															
															$("#apprPeopleSid1").html(options);
															$(_this).fillForm({tableApply : data.tableApply});
															for (var i=0;i<array.length;i++) {
																if(array[i]==data.tableApply.apprPeopleSid){
																	document.getElementById("people"+i).selected = true;
																}
															}
														}
														if (bizInfo.length != 0) {
															if (bizInfo.status == "0") {

															} else if (bizInfo.status == "1") {

															} else if (bizInfo.status == "2") {
																document.getElementById("newMemocs").style.display = "";
															} else if (bizInfo.status == "3") {
																document.getElementById("newMemocs").style.display = "";
															}
														}
													} else {
														alert(data.responseMessage.message);
														$("#sealUseTaskInfo1").dialog("close");
													}

												});
							}
						}
					});

};
// zjh
function applyUseSeakTask() {
	hasFile = false;
	$("#hasFile").val("0");
	$("#sealUseTaskInfo").dialog("open");
}
function batchApplyUseSeakTask() {
	var listTradeCode = "";
	var ids = $("#useSealList").jqGrid("getGridParam", "selarrrow");
	if (ids.length > 0) {
		$(ids).each(function(index, id) {
			var row = $("#useSealList").jqGrid("getRowData", id);
			if (row.status == "等待审批(Pending Approval)") {
				
				//判断是否有权限
				var url =ctx + "/mechseal/task/sealUseApprTaskHfAction_checkPower.action";
				var param = {"lstradeCode":row.tradeCode}
				var result = tool.ajaxRequest(url, param);
				if (result.success && result.response.responseMessage.success){
					listTradeCode += "'" + row.tradeCode + "',";
				}else{
					alert("没有权限");
					return
				}	
			} else if (row.status == "审批通过(Approved)") {
				alert("流水号为" + row.tradeCode + "的任务审批通过,请重新选择！");
				location.reload();
				return;
			} else if (row.status == "审批拒绝(Rejected)") {
				alert("流水号为" + row.tradeCode + "的任务为审批拒绝任务请重新选择!");
				location.reload();
				return;
			} else {
				alert("有未知状态任务,请重新选择！");
				location.reload();
				return;
			}
		});
	} else {
		alert("请选择任务批量审批");
		return;
	}
	
	if(listTradeCode==""){
		return;
	}
	$("#batchBtn").attr("disabled", true);
	listTradeCode = listTradeCode.substring(0, listTradeCode.length - 1);
	var url = ctx
			+ "/sealusetask/create/sealUsehfTask_createBatchApproveSealTask.action";
	var param = {
		"listTradeCode" : listTradeCode
	};
	var result = tool.ajaxRequest(url, param);
	if (result.response.webResponseJson.state == "normal") {
		var files = result.response.webResponseJson.data;
		if (files.result == "success") {
			alert("批量通过成功！");
			$("#batchBtn").attr("disabled", false);
			location.reload();
			return;
		} else {
			alert(result.response.webResponseJson.message);
			$("#batchBtn").attr("disabled", false);
			location.reload();
			return;
		}
	} else {
		$("#batchBtn").attr("disabled", false);
		var message = result.response.webResponseJson.message;
		alert(message);
		queryApplyInfoForTerm();
		return;
	}
}

function batchApplyCancelSeakTask() {
	var listTradeCode = "";
	var ids = $("#useSealList").jqGrid("getGridParam", "selarrrow");
	if (ids.length > 0) {
		$(ids).each(function(index, id) {
			var row = $("#useSealList").jqGrid("getRowData", id);
			if (row.status == "等待审批(Pending Approval)") {
				
				//判断是否有权限
				var url =ctx + "/mechseal/task/sealUseApprTaskHfAction_checkPower.action";
				var param = {"lstradeCode":row.tradeCode}
				var result = tool.ajaxRequest(url, param);
				if (result.success && result.response.responseMessage.success){
					listTradeCode += "'" + row.tradeCode + "',";
				}else{
					alert("没有权限");
					return
				}	

			} else if (row.status == "审批通过(Approved)") {
				alert("流水号为" + row.tradeCode + "的任务审批通过,请重新选择！");
				return;
			} else if (row.status == "审批拒绝(Rejected)") {
				alert("流水号为" + row.tradeCode + "的任务为审批拒绝任务请重新选择!");
				return;
			} else {
				alert("有未知状态任务,请重新选择！");
				return;
			}
		});
	} else {
		alert("请选择批量拒绝任务");
		return;
	}
	
	if(listTradeCode==""){
		return;
	}
	
	if(listTradeCode.split(",").length<ids.length)
	{
		location.reload();
		return;
	}
	listTradeCode = listTradeCode.substring(0, listTradeCode.length - 1);
	var url = ctx
			+ "/sealusetask/create/sealUsehfTask_createBatchApproveCancelSealTask.action";
	var param = {
		"listTradeCode" : listTradeCode
	};
	var result = tool.ajaxRequest(url, param);
	if (result.response.webResponseJson.state == "normal") {
		var files = result.response.webResponseJson.data;
		if (files.result == "success") {
			alert("批量拒绝成功！");
			location.reload();
			return;
		} else {
			alert(result.response.webResponseJson.message);
			location.reload();
			return;
		}
	} else {
		var message = result.response.webResponseJson.message;
		alert(message);
		queryApplyInfoForTerm();
		return;
	}
}
// zjh
function applyUseSelect() {
	hasFile = false;
	var returnValue = window.showModalDialog("sealUseApplyHfQueryTask.jsp",loginPeople,"dialogWidth=880px;dialogHeight=510px;resizable:no;dialogLeft:350px;dialogTop:100px;status:no;scroll:no;resizable:no");
	document.getElementById("sealType").value = returnValue.sealType;
	document.getElementById("sealTypeName").value = returnValue.sealTypeName;
	document.getElementById("sealName").value = returnValue.sealName;
	document.getElementById("sealOrgNo1").value = returnValue.sealOrgNo;
	document.getElementById("sealOrgName").value = returnValue.sealOrgName;
}
function queryApplyInfoForTerm() {
	$("#useSealList").jqGrid("search", "#queryForm");
};

/**
 * 初始化机构数据
 */
function initOrgSelect() {
	var url = ctx + "/sealusetask/create/sealUsehfTask_initSealOrg.action";
	var result = tool.ajaxRequest(url, null);
	if (result.response.webResponseJson.state == "normal") {
		var orgArray = result.response.webResponseJson.data;
		$.each(orgArray, function(index, organize) {
			$("#sealOrg").append("<option value='" + organize.orgNo + "'>"+ organize.orgName + "</option>");
		});
	} else {
		var message = reslut.response.webResponseJson.message;
		alert(message);
	}
}
function checkFile(fileValue) {
	var flag = true;
	if ("" == fileValue) {
		alert("请选择待上传文件");
		return false;
	}

	for ( var i = 0; i < $("#fileTd").find("input").length; i++) {
		$("#fileTd").after("<input name=\"tableApply.filepaths\" type=\"hidden\" value=\""+ $("#fileTd").find("input")[i].value + "\" />");
	}
	return true;
}
/**
 * 提交申请
 */
// zjh
function submitApply(saveOrCreate) {
	
	var newMemoc = $("#newMemoc").val();
	if ("" != newMemoc) {
		if (newMemoc.length > 100) {
			alert("审批意见不能超过100");
	        return false;
		}
	}
	
	//判断是否有权限
	var lstradeCode = $("#id").val();
	var url =ctx + "/mechseal/task/sealUseApprTaskHfAction_checkPower.action";
	var param = {"lstradeCode":lstradeCode}
	var result = tool.ajaxRequest(url, param);
	if (result.success && result.response.responseMessage.success){
	}else{
		alert("没有权限");
		return
	}
	 
	$("#submitBtnpass").attr("disabled", true);
	$("#submitBtnrecvice").attr("disabled", true);
	if (saveOrCreate) {
		$("#status").val("2");
		$("#memo1").val("审批通过");
		sealUseApplyForm.action = ctx+ "/sealusetask/create/sealUsehfTask_createApproveSealTask.action";
		$('#sealUseApplyForm').submit();
	} else {
		$("#status").val("3")
		$("#memo1").val("审批拒绝");
		sealUseApplyForm.action = ctx+ "/sealusetask/create/sealUsehfTask_createApproveSealTask.action";
		$("#sealUseApplyForm").submit();
	}
}

function cancelApply() {
	$("#sealUseApplyForm")[0].reset();
	$("#sealUseApplyForm1")[0].reset();
	$("#sealUseTaskInfo").dialog("close");
	location.reload();

}

function checkLength(id, maxlength) {
	var value = $(id).val();
	if (value.length > maxlength) {
		alert("输入字数不能超过:" + maxlength);
		$(id).focus();
	}
}

/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo) {
	var organizationSid = top.loginPeopleInfo.orgSid;
	//var organizationSid = "00000000000000000000000000000000";
	$("#organizationSid_Item").radioOrgTree(
			true,
			organizationSid,
			0,
			false,
			function(event, treeId, treeNode) {
				if (treeNode) {
					$("#organizationSid_Item").val(
							treeNode.organizationName + "("
									+ treeNode.organizationNo + ")");
					$("#sealOrgNo").val(treeNode.organizationNo);
				}
			});
}

/**
 * 选择申请机构
 */
function checkOrganizationItemApp(organizationNo) {
	var organizationSid = top.loginPeopleInfo.orgSid;
	//var organizationSid = "00000000000000000000000000000000";
	$("#organizationSid_Item").radioOrgTree(
			true,
			organizationSid,
			0,
			false,
			function(event, treeId, treeNode) {
				if (treeNode) {
					$("#applyPeopleOrgName_Item").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
					$("#applyPeopleOrgName").val(treeNode.organizationName);
				}
			});
}
function initOrgNo() {
	loginPeople = top.loginPeopleInfo;
	$("#organizationSid_Item").val(
			loginPeople.orgName + "(" + loginPeople.orgNo + ")");
	$("#sealOrgNo").val(loginPeople.orgNo);
}

/**
 * 重置查询条件
 */
function resetMethod() {
	$("#queryForm")[0].reset();
	//initOrgNo();
}
