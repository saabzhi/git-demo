//验证某个值为正整数的正则表达式
var login_people = null; // 人员信息
var roleGroupMap = new Map();
var scanNum = null;
var hasFile = false;
var fileHas = false;
var loginPeople = null;
var filePath1 = null;
var listId = null;
var sealUseConstant = new Object();
sealUseConstants.SealUseApplyStatusApply = {
	"0" : "启用", 
	"1" : "停用",
	"2" : "销毁" 
};

/**
 * 页面初始化加载
 */
$(document).ready(function() {
	initUseSealPage();
	initTaskList();
	initOrgNo();
	initApplyDialog();
	initSealApproverDialog();
});

sealUseConstants.SealUseApplyStatus = {
		"0" : "等待提交(Pending Submission)",
		"1" : "等待审批(Pending Approval)",
		"2" : "审批通过(Approved)",
		"3" : "审批拒绝(Rejected)"
};

/**
 * 页面初始化加载
 */
$(function() {
	var options = {
		type : 'POST',
		url : ctx
				+ "/sealusetask/create/sealUsehfTask_createUseSealTask.action",
		success : showResponse,
		error : function(xhr, status, err) {
			alert("操作失败");
		}
	};
	$("#sealUseApplyForm").submit(function() {
		$(this).ajaxSubmit(options);
		return false; // 防止表单自动提交
	});
});

function showResponse(data, status) {
	data = data.substring("0", data.indexOf("}")+1);
	data = jQuery.parseJSON(data);
	if (data.result == 'success') {
		alert("操作成功Done");
		$("#useSealList").jqGrid("resetSelection");
		$("#sealUseApplyForm")[0].reset();
		$("#sealUseApplyForm1")[0].reset();
		$("#sealUseTaskInfo").dialog("close");
		location.reload();
	}else{
		alert("操作失败");
		$("#useSealList").jqGrid("resetSelection");
		$("#sealUseApplyForm")[0].reset();
		$("#sealUseApplyForm1")[0].reset();
		$("#sealUseTaskInfo").dialog("close");
	}
};

/**
 * 初始化任务列表
 */
function initTaskList() {
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	var url = ctx + "/mechseal/task/sealUseApprTaskHfAction_gainTaskList.action?_t=" + _t;
	// 用印信息列表
	$("#useSealList").jqGrid(
		{
			width : pageContentWidth,
			height : tableHeight + "px",
			url : url,
			multiselect : false,
			rowNum : 20,
			rownumbers : true,
			sortable : true,// 是否排序
			sortname : "applyDate",
			sortorder : "desc",
			multiselect : true,
			rowList : [ 20, 50, 100 ],// "印章类型", "印章所属机构", "印章名称",
			colNames : [ "流水号(Serial Number)", "申请机构名称(Applicant: Affiliated Institution)", "申请人(Applicant)", "申请时间(Application Date)", "审批人(Authorizer)", "印章类型(Chop Type)", "印章类型(Chop Type)", "印章所属机构(Chop Custodian Party)", "印章名称(Chop Name)", "文件名称(File Name)", "申请审批状态(Chop Applying and Authorizing Status)", "操作(Action)" ],
			colModel : [
				{
					name : "tradeCode",
					index : "tradeCode",
					align : "center",
					sortable : false
				},
				{
					name : "applyPeopleOrgName",
					index : "applyPeopleOrgName",
					align : "center",
					sortable : false
				},
				{
					name : "peopleName",
					index : "peopleName",
					align : "center",
					sortable : false
				},
				{
					name : "applyDate",
					index : "applyDate",
					align : "center",
					sortable : false
				},
				{
					name : "nextHandlerName",
					index : "nextHandlerName",
					align : "center",
					sortable : false
				},
				{ 
					name : "sealType", 
					index : "sealType",
					align : "center",
					hidden:true,
					sortable : false 
				},
				{ 
					name : "sealTypeName", 
					index : "sealTypeName",
					align : "center",
					sortable : false 
				},
				{ 
					name : "sealOrgName", 
					index : "sealOrgName",
					align : "center" ,
					sortable : false
				},
				{
					name : "title",
					index : "title",
					align : "center",
					sortable : false
				},
				{
					name : "applyTitle",
					index : "applyTitle",
					align : "center",
					sortable : false
				},
				{
					name : "status",
					index : "status",
					align : "center",
					sortable : false,
					formatter : function(value, options, rData) {
						return sealUseConstants.SealUseApplyStatus[value];
					}
				},
				{
					name : "id",
					index : "id",
					align : "center",
					sortable : false,
					formatter : function(value, options, rData) {
						return "<input type='button' style=\" width:70px;  \" onclick=\"showDetail('" + value + "');\" value='查看(View)' />";
					}
				}
			],
		pager : "#useSealPager",
		caption : "申请列表(Application Information)"
	}).trigger("reloadGrid");
	$("#useSealList").navGrid("#useSealPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};

function updateUseSeakTask() {
	var ids = $("#useSealList").jqGrid("getGridParam", "selarrrow");
	if (ids.length > 1 || ids.length == 0) {
		alert("请选择单笔任务修改");
		$("#useSealList").jqGrid("resetSelection");
		return;
	}
	var row = $("#useSealList").jqGrid("getRowData", ids[0]);
	if (row.status != "等待提交(Pending Submission)") {
		alert("请选择未提交任务进行修改");
		$("#useSealList").jqGrid("resetSelection");
		return;
	}
	var id = row.tradeCode;
	$("#sealUseTaskInfo").data("sealUseApplyForm", id).dialog("open");
};

function showDetail(id) {
	$("#sealUseTaskInfo1").data("sealUseApplyForm1", id).dialog("open");
};

function initUseSealPage() {
	$("#submitForm").click(function() {
		queryApplyInfoForTerm();
	});
	$("#clearForm").click(function() {
		$("#queryForm")[0].reset();
	});
	$("#sealUseTaskInfo").dialog({
		autoOpen : false,
		resizable : false,
		width : 650,
		height : 'auto',
		modal : true,
		position : {
			at : "center"
		},
		close : function() {
			initTaskList();
			num = 1;
			$("#queryForm")[0].reset();
			$("#sealUseApplyForm")[0].reset();
			$("#sealUseApplyForm1")[0].reset();
			location.reload();
		},
		open : function() {
			var _this = this;
			var id = $(this).data("sealUseApplyForm");
			if (id) {// 更新
				$.post(
					ctx+ "/mechseal/task/sealUseApprTaskHfAction_gainUpdateTask.action?_t="+ _t+"3",
					{"bizInfo.id" : id},
					function(data) {
						if (data.responseMessage.success) {														
							var mechSealInfos = data.mechSealInfos;
							var mechSealFiles = data.mechSealFiles;
							var bizInfo = data.bizInfo;
							var html = "";
							if (mechSealFiles !=null) {
								alert("请不要上传高度敏感信息(Please do not upload highly-restricted information)!");
								hasFile = true;
								document.getElementById("docwordTr").style.display = "";
								for ( var i = 0; i < mechSealFiles.length; i++) {
									var htmls = "<td>"+ mechSealFiles[i].fileDesc+ "</td>";
									html += "<div><td>"+ mechSealFiles[i].fileDesc+ "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ "<a style=\"font-weight:700;\" href='"+ ctx+ "/mechseal/task/FileDownload.action?filePath="+ mechSealFiles[i].originalStore+ "'>下载(download)</a></td></div>";
                                 	filePath1 = mechSealFiles[i].filePath;
								}
								$('#docword1').html(html);
								$("#hasFile").val("1");
								var array =new Array();
								var arrayname =new Array();
								array= data.tableApply.apprPeople.split(",");
								arrayname= data.tableApply.apprPeopleName.split(",");
								var options = '';
								options+="<option id='people' value=\"\">--请选择(Please select)--</option>";
								for (var i=0;i<array.length;i++) {
									options += "<option  id='people"+i+"' value=\""+ array[i]+"\">" + arrayname[i] + "</option>";
								}															
								$(".apprPeopleSid").html(options);
								$(_this).fillForm({tableApply : data.tableApply});
								for (var i=0;i<array.length;i++) {
									if(array[i]==data.tableApply.apprPeopleSid){
										document.getElementById("people"+i).selected = true;
									}
								}
							} else {
								alert("请不要上传高度敏感信息(Please do not upload highly-restricted information)!");
								hasFile = true;		
								fileHas=true;
								$("#hasFile").val("1");
								var array =new Array();
								var arrayname =new Array();
								array= data.tableApply.apprPeople.split(",");
								arrayname= data.tableApply.apprPeopleName.split(",");
								var options = '';
								options+="<option id='people' value=\"\">--请选择(Please select)--</option>";
								for (var i=0;i<array.length;i++) {
									options += "<option  id='people"+i+"' value=\""+ array[i]+"\">" + arrayname[i] + "</option>";
								}															
								$(".apprPeopleSid").html(options);
								$(_this).fillForm({tableApply : data.tableApply});
								for (var i=0;i<array.length;i++) {
									if(array[i]==data.tableApply.apprPeopleSid){
										document.getElementById("people"+i).selected = true;
									}
								}
							}
						} else {
							alert(data.responseMessage.message);
							$("#sealUseApplyForm")[0].reset();
							$("#sealUseApplyForm1")[0].reset();
							$("#sealUseTaskInfo").dialog("close");
						}
					}
				);
			}else{
				alert("请不要上传高度敏感信息(Please do not upload highly-restricted information)!");
			}
		}
	});
	$("#sealUseTaskInfo1").dialog({
		autoOpen : false,
		resizable : false,
		width : 650,
		height : 'auto',
		modal : true,
		position : {
			at : "center"
		},
		close : function() {
			initTaskList();
			$("#sealUseApplyForm1")[0].reset();
			$("#sealUseApplyForm")[0].reset();
			location.reload();
		},
		open : function() {
			var _this = this;
			var id = $(this).data("sealUseApplyForm1");
			if (id) {// 更新
				$.post(
					ctx+ "/mechseal/task/sealUseApprTaskHfAction_gainUpdateTask.action?_t="+ _t,
					{
						"bizInfo.id" : id
					},
					function(data) {
						if (data.responseMessage.success) {
							var mechSealInfos = data.mechSealInfos;
							var mechSealFiles = data.mechSealFiles;
							var bizInfo = data.bizInfo;
							var filenetautoid =data.filenetautoid;
							var filesynchroStatus =data.filesynchroStatus;
							var html = "";
							if (mechSealFiles!= null) {
								hasFile = true;
								document.getElementById("docwordTr1").style.display = "";
								var html = "";
								//上传filenet后则显示流水号
								if(filesynchroStatus!=2){
									for ( var i = 0; i < mechSealFiles.length; i++) {
										var htmls = "<td>"+ mechSealFiles[i].fileDesc+ "</td>";
										html += "<div><td>"+ mechSealFiles[i].fileDesc+ "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ "<a style=\"font-weight:700;\" href='"+ ctx+ "/mechseal/task/FileDownload.action?filePath="+ mechSealFiles[i].originalStore+ "'>下载(download)</a></td></div>";
										filePath1 = mechSealFiles[i].filePath;
									}
								}else{
									var htmls = "<td></td>";
									html += "<div>文件已转存至FILENET, 附件流水号:"+id+"0; <span color='red'> 请联系总行/分行系统管理员获取</span> </div>";
								}								
								$('#docword2').html(html);
								$("#hasFile").val("1");
								$(_this).fillForm({tableApply : data.tableApply});
								$("#sealUseTaskInfo1").dialog("open");
								var array =new Array();
								var arrayname =new Array();
								array= data.tableApply.apprPeople.split(",");
								arrayname= data.tableApply.apprPeopleName.split(",");
								var options = '';
								options+="<option id='people' value=\"\">--请选择(Please select)--</option>";
								for (var i=0;i<array.length;i++) {
									options += "<option  id='people"+i+"' value=\""+ array[i]+"\">" + arrayname[i] + "</option>";
								}
								$("#apprPeopleSid1").html(options);
								$(_this).fillForm({tableApply : data.tableApply});
								for (var i=0;i<array.length;i++) {
									if(array[i]==data.tableApply.apprPeopleSid){
										document.getElementById("people"+i).selected = true;
									}
								}
							} else {
								hasFile = true;								
								$("#hasFile").val("1");
								$(_this).fillForm({tableApply : data.tableApply});
								$("#sealUseTaskInfo1").dialog("open");
								var array =new Array();
								var arrayname =new Array();
								array= data.tableApply.apprPeople.split(",");
								arrayname= data.tableApply.apprPeopleName.split(",");
								var options = '';
								options+="<option id='people' value=\"\">--请选择(Please select)--</option>";
								for (var i=0;i<array.length;i++) {
									options += "<option  id='people"+i+"' value=\""+ array[i]+"\">" + arrayname[i] + "</option>";
								}
								$("#apprPeopleSid1").html(options);
								$(_this).fillForm({tableApply : data.tableApply});
								for (var i=0;i<array.length;i++) {
									if(array[i]==data.tableApply.apprPeopleSid){
										document.getElementById("people"+i).selected = true;
									}
								}
							}
							if (bizInfo.length != 0) {
								if (bizInfo.status =="0") {
									$("#applyresult").val("待提交");
								} else if (bizInfo.status =="1") {
									$("#applyresult").val("待审批");
								} else if (bizInfo.status =="2") {
									$("#applyresult").val("审批通过");
									document.getElementById("newMemocs").style.display = "";
								} else if (bizInfo.status =="3") {
									$("#applyresult").val("审批拒绝");
									document.getElementById("newMemocs").style.display = "";
								}
							}
						} else {
							alert(data.responseMessage.message);
							$("#sealUseTaskInfo1").dialog("close");
						}
					}
				);
			}
		}
	});
};

function applyUseSeakTask() {
	hasFile = false;
	$("#hasFile").val("0");
	$("#sealUseTaskInfo").dialog("open");
};

function batchApplyUseSeakTask() {
	var listTradeCode = "";
	var ids = $("#useSealList").jqGrid("getGridParam", "selarrrow");
	if (ids.length > 0) {
		$(ids).each(function(index, id) {
			var row = $("#useSealList").jqGrid("getRowData", id);
			if (row.status == "等待提交(Pending Submission)") {
				listTradeCode += "'" + row.tradeCode + "',";
			} else if (row.status == "等待审批(Pending Approval)") {
				alert("流水号为" + row.tradeCode + "的任务已提交,请重新选择！");
				return ;
			} else if (row.status == "审批通过(Approved)") {
				alert("流水号为" + row.tradeCode + "的任务审批通过,请重新选择！");
				return ;
			} else if (row.status == "审批拒绝(Rejected)") {
				if (confirm("流水号为" + row.tradeCode + "的任务为审批拒绝任务,确认重新提交吗？")) {
					listTradeCode += "'" + row.tradeCode + "',";
				}
			} else {
				alert("有未知状态任务,请重新选择！");
				return ;
			}
		});
	} else {
		alert("请选择任务批量提交");
		return;
	}
	listTradeCode = listTradeCode.substring(0, listTradeCode.length - 1);
	if(listTradeCode.split(",").length<ids.length)
	{
		location.reload();
		return;
	}
	var url = ctx + "/sealusetask/create/sealUsehfTask_createBatchUseSealTask.action";
	var param = {
		"listTradeCode" : listTradeCode
	};
	var result = tool.ajaxRequest(url, param);
	if (result.response.webResponseJson.state == "normal") {
		var files = result.response.webResponseJson.data;
		if (files.result == "success") {
			alert("批量提交成功！");
			location.reload();
			return;
		} else {
			alert(result.response.webResponseJson.message);
			location.reload();
			return;
		}
	} else {
		var message = result.response.webResponseJson.message;
		alert(message);
		queryApplyInfoForTerm();
		return;
	}
};

// zjh  印章名称
//function applyUseSelect() {
//	hasFile = false;
//	//判断是否是egde浏览器，其他浏览器正常访问
//	if(window.showModalDialog==undefined){
//		var returnValue = window.open("sealUseApplyHfQueryTask.jsp?orgNo=" + loginPeople.orgNo + "&orgName=" + loginPeople.orgName,"","width=880,height=510,left=350,top=100,toolbar=no,menubar=no,scrollbars=no,resizable=no,location=no,status=no");
//	}else{
//		var returnValue = window.showModalDialog("sealUseApplyHfQueryTask.jsp",loginPeople,"dialogWidth=880px;dialogHeight=510px;resizable:no;dialogLeft:350px;dialogTop:100px;status:no;scroll:no;resizable:no");
//	}
//	if(returnValue==undefined){
//		return;
//	}
//	//判断是否是egde浏览器，其他浏览器照常
//	if(window.showModalDialog!=undefined){
//		document.getElementById("sealType").value = returnValue.sealType;
//		document.getElementById("sealTypeName").value = returnValue.sealTypeName;
//		document.getElementById("sealName").value = returnValue.sealName;
//		document.getElementById("sealOrgNo1").value = returnValue.sealOrgNo;
//		document.getElementById("sealOrgName").value = returnValue.sealOrgName;
//		document.getElementById("deviceNum").value = returnValue.deviceNum;
//		document.getElementById("fontFace").value = returnValue.faceFont;
//		document.getElementById("sealNum").value = returnValue.sealNum;
//		document.getElementById("sealautoId").value = returnValue.sealApprovalPeople;
//		document.getElementById("sealId").value = returnValue.autoId;
//	}
//	
////	var array =new Array();
////	var arrayname =new Array();
////	var arr=returnValue.sealApprovalPeople;
////	var options = '';
////	options+="<option value=\"\">--请选择(Please select)--</option>";
////	if(arr==""){
////		
////	}else{
////		array=returnValue.sealApprovalPeople.split(",");
////		arrayname=returnValue.sealApprovalPeopleName.split(",");
////
////		for (var i=0;i<array.length;i++) {
////			options += "<option value=\""+ array[i]+"\">" + arrayname[i] + "</option>";
////		}
////	}
////	
////	$(".apprPeopleSid").html(options);
//	
//}


//审批人
//function apprPeopleSelect() {
//	hasFile = false;
//	var sealautoId= $("#sealautoId").val();
//	if(sealautoId==""){
//		alert("请选择印章！");
//		return;
//	}
//	//判断是否是egde浏览器，其他浏览器正常访问
//	if(window.showModalDialog==undefined){
//		var returnValue = window.open("sealUseApplyHfQueryPeople.jsp?sealautoId=" + sealautoId + "&boolenPage=1","","width=880,height=510,left=350,top=100,toolbar=no,menubar=no,scrollbars=no,resizable=no,location=no,status=no");
//	}else{
//		var returnValue = window.showModalDialog("sealUseApplyHfQueryPeople.jsp",sealautoId,"dialogWidth=880px;dialogHeight=510px;resizable:no;dialogLeft:350px;dialogTop:100px;status:no;scroll:no;resizable:no");
//	}
//	if(returnValue==undefined){
//		return;
//	}
//	//判断是否是egde浏览器，其他浏览器正常访问
//	if(window.showModalDialog!=undefined){
//		document.getElementById("apprPeopleName").value = returnValue.peopleName;
//		document.getElementById("apprPeopleSid").value = returnValue.sid;
//	}
//};

function queryApplyInfoForTerm() {
	$("#useSealList").jqGrid("search", "#queryForm");
};

/**
 * 初始化机构数据
 */
function initOrgSelect() {
	var url = ctx + "/sealusetask/create/sealUsehfTask_initSealOrg.action";
	var result = tool.ajaxRequest(url, null);
	if (result.response.webResponseJson.state == "normal") {
		var orgArray = result.response.webResponseJson.data;
		$.each(orgArray, function(index, organize) {
			$("#sealOrg").append("<option value='" + organize.orgNo + "'>" + organize.orgName + "</option>");
		});
	} else {
		var message = reslut.response.webResponseJson.message;
		alert(message);
	}
};

function checkFile(fileValue) {
	var flag = true;
	if ("" == fileValue) {
		alert("请选择待上传文件");
		return false;
	}

	for ( var i = 0; i < $("#fileTd").find("input").length; i++) {
		$("#fileTd").after("<input name=\"tableApply.filepaths\" type=\"hidden\" value=\""+ $("#fileTd").find("input")[i].value + "\" />");
	}
	return true;
};

function getLentghStr(str) {
	  return str.replace(/[\u0391-\uFFE5]/g,"aa").length;  //先把中文替换成两个字节的英文，在计算长度
};  

/**
 * 提交申请
 */
// zjh
function submitApply(saveOrCreate) {
	var sealName= $("#sealName").val();
	if ("" == sealName) {
		alert("印章名称为空");
		return false;
	}
	var sealTypeName= $("#sealTypeName").val();
	if ("" == sealTypeName) {
		alert("印章类型为空");
		return false;
	}
	var sealOrgName= $("#sealOrgName").val();
	if ("" == sealOrgName) {
		alert("印章所属机构为空");
		return false;
	}
	var apprPeopleSid= $("#apprPeopleSid").val();
	if ("" == apprPeopleSid) {
		alert("请选择审批人");
		return false;
	}
	var applyTitle= $("#applyTitle").val();
	var runSealFunc= $("#runSealFunc").val();
	if ("1" == runSealFunc) {
		$("#hasFile").val("1");
		if ("" == applyTitle) {
			alert("请填写文件名称");
			return false;
		}else{
			if (getLentghStr(applyTitle) > 256) {
				alert("文件名称长度不能超过256字符");
		        return false;
			}
		}
		/*if ("" != applyTitle ) {
			if(getLentghStr(applyTitle) > 256){
				alert("文件名称长度不能超过256字符");
		        return false;
			}
		}*/
	}else{
		var fileType= $("#fileType").val();
		if ("" == fileType) {
			alert("请选择文件类型");
			return false;
		}
		if ("" == applyTitle) {
			alert("请填写文件名称");
			return false;
		}else{
			if (getLentghStr(applyTitle) > 256) {
				alert("文件名称长度不能超过256字符");
		        return false;
			}
		}
		var fileValue = $("#fileinput").val();
		if (!hasFile) {
			
			if (!checkFile(fileValue)) {
				return;
			};
		} else {
			if (fileValue != "") {
				$("#hasFile").val("0");
				if (!checkFile(fileValue)) {
					return;
				};
			}else{
				if(fileHas){
					if (!checkFile(fileValue)) {
						return;
					};	
				}
			}
		}
	}
	var useSealReason= $("#useSealReason").val();
	if ("" != useSealReason) {
		if (getLentghStr(useSealReason) > 300) {
			alert("用印理由长度不能超过300字符或150个汉字");
	        return false;
		}
	}else {
		alert("请输入用印理由");
		return false;
	}
	
	//判断审批人是否存在
	var url = ctx + "/sealusetask/create/sealUsehfTask_queryPeople.action";
	var param = {"apprPeopleSid" : apprPeopleSid};
	var result = tool.ajaxRequest(url, param);
	if (result.response.webResponseJson.state == "normal") {
		$("#submitBtn").attr("disabled") == "disabled";
		if (saveOrCreate) {
	    	ocxbase_messageHandler.showTipMessage("正在提交申请中,请稍等...");
			$("#status").val("1");
			$("#memo1").val("申请任务");
			// initFlowParamInfo();
			sealUseApplyForm.action = ctx + "/sealusetask/create/sealUsehfTask_createUseSealTask.action";
			$('#sealUseApplyForm').submit();
		} else {
			ocxbase_messageHandler.showTipMessage("正在保存,请稍等...");
			$("#status").val("0")
			$("#memo1").val("保存任务");
			sealUseApplyForm.action = ctx + "/sealusetask/create/sealUsehfTask_createUseSealTask.action";
			$("#sealUseApplyForm").submit();
		}
	} else {
		var message = result.response.webResponseJson.message;
		alert(message);
		return;
	}
	
};

function deleteApply() {
	var url = ctx + "/sealusetask/create/sealUsehfTask_deleteTask.action";
	var param = {
		"tableApply.tradeCode" : $("#tradeCode1").val()
	};
	var data = tool.ajaxRequest(url, param);
	if (data.response.webResponseJson.state == "normal") {
		alert("删除成功");
		queryApplyInfoForTerm();
		$("#sealUseTaskInfo").dialog("close");
	}else{
		alert(data.response.webResponseJson.message);
		queryApplyInfoForTerm();
		$("#sealUseTaskInfo").dialog("close");
	}
};

function checkLength(id, maxlength) {
	var value =id;
	if (value.length > maxlength) {
		alert("输入字数不能超过:" + maxlength);
		$(id).focus();
	}
};

function checkReasonLength(id, maxlength) {
	var value = id;
	if (value.length > maxlength) {
		alert("最大字符不能超过:" + maxlength);
        return false;
	}
};

/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo) {
	var organizationSid = "00000000000000000000000000000000";
	$("#organizationSid_Item").radioOrgTree(
		true,
		organizationSid,
		0,
		false,
		function(event, treeId, treeNode) {
			if (treeNode) {
				$("#organizationSid_Item").val(treeNode.organizationName + "("+ treeNode.organizationNo + ")");
				$("#sealOrgNo").val(treeNode.organizationNo);
			}
		}
	);
};

function initOrgNo() {
	loginPeople = top.loginPeopleInfo;
	$("#organizationSid_Item").val(loginPeople.orgName + "(" + loginPeople.orgNo + ")");
	$("#sealOrgNo").val(loginPeople.orgNo);
};

function gradeChange(){
	var objs=document.getElementById("runSealFunc");
	var grade=objs.options[objs.selectedIndex].value;
	if(grade==1){
		$("#fileType").attr("disabled", "disabled");
		$("#fileinput").attr("disabled", "disabled");
	}else{
		$("#fileType").attr("disabled", false);
		$("#fileinput").attr("disabled", false);
		
	}
};

/**
 * 重置查询条件
 */
function resetMethod() {
	$("#queryForm")[0].reset();
	//initOrgNo();
};

//$("#apprPeopleSid").autocomplete(["c++","java", "php", "coldfusion","javascript"], { 
//	width: 320, 
//	max: 4, 
//	highlight: false, 
//	multiple: true, 
//	multipleSeparator: "", 
//	scroll: true, 
//	scrollHeight: 300 
//	}); 


//// 模糊查询
//function query123(){
//    $('#apprPeopleSid').autocomplete({
//               source : tableApply.apprPeopleSid
//           });
//}

//*********************************************************				印章选框窗口					*************************************************************8

/**
 * 初始化印章选择列表
 */
function initTaskListApply() {
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	var url = ctx+ "/mechseal/task/sealUseInstallAction_gainSealInstallListOwnerSelf.action";
	$('#useSealListApply').jqGrid('GridUnload');
	// 用印信息列表
	$("#useSealListApply").jqGrid({
		width : pageContentWidth,
		height : tableHeight + "px",
		url : url,
		multiselect : false,
		rowNum : 20,
		rownumbers : true,
		sortable : true,// 是否排序
		sortname : "applyDate",
		sortorder : "desc",
		ondblClickRow : function(row) {
			var rowData = $("#useSealListApply").getRowData(row);
			//赋值
			$("#sealType").val(rowData.sealType);
			$("#sealTypeName").val(rowData.sealTypeName);
			$("#sealName").val(rowData.sealName);
			$("#sealOrgNo1").val(rowData.sealOrgNo);
			$("#sealOrgName").val(rowData.sealOrgName);
			$("#deviceNum").val(rowData.deviceNum);
			$("#fontFace").val(rowData.faceFont);
			$("#sealNum").val(rowData.sealNum);
			$("#sealautoId").val(rowData.sealApprovalPeople);
			$("#sealId").val(rowData.autoId);
			//关闭弹窗口
			$("#pageHeaderApply").dialog("close");
		},
		rowList : [ 20, 50, 100 ],
		colNames : [ "ID","所属机构(Chop Custodian Party)", "所属机构名称Chop: Affiliated Institution Name", "印章种类(Chop Group)", "印章类型(Chop Type)", "印章类型(Chop Type)", "印章名称(Chop Name)", "维护时间(Maintenance Date)", "章面字样(Text on the chop) ", "审批人(Authorizer)", "审批人名称(Authorizer Name)", "印章保管人(Chop Custodian)", "印章保管人(Chop Custodian)", "设备编号(Device ID)", "槽位(Slot No)", "印章状态(Chop Status)"],
		colModel : [
		    {
				name : "autoId",
				index : "autoId",
				align : "center",
				hidden:true,
				sortable : false
			},
			{
				name : "sealOrgNo",
				index : "sealOrgNo",
				align : "center",
				sortable : false
			}, 
			{
				name : "sealOrgName",
				index : "sealOrgName",
				align : "center",
				sortable : false
			}, 
			{
				name : "sealGroup",
				index : "sealGroup",
				align : "center",
				sortable : false
			}, 
			{
				name : "sealType",
				index : "sealType",
				hidden:true,
				align : "center",
				sortable : false
			}, 
			{
				name : "sealTypeName",
				index : "sealTypeName",
				align : "center",
				sortable : false
			}, 
			{
				name : "sealName",
				index : "sealName",
				align : "center",
				sortable : false
			}, 
			{
				name : "maintainTime",
				index : "maintainTime",
				align : "center",
				sortable : false
			}, 
			{
				name : "faceFont",
				index : "faceFont",
				align : "center",
				sortable : false
			}, 
			{
				name : "sealApprovalPeople",
				index : "sealApprovalPeople",
				align : "center",
				width : 80,
				hidden:true,
				sortable : false
			}, 
			{
				name : "sealApprovalPeopleName",
				index : "sealApprovalPeopleName",
				align : "center",
				width : 80,
				sortable : false
			}, 
			{
				name : "sealStoragePeople",
				index : "sealStoragePeople",
				hidden:true,
				align : "center",
				sortable : false
			},
			{
				name : "sealStoragePeopleName",
				index : "sealStoragePeopleName",
				align : "center",
				sortable : false
			},
			{
				name : "deviceNum",
				index : "deviceNum",
				align : "center",
				hidden:true,
				sortable : false
			},
			{
				name : "sealNum",
				index : "sealNum",
				align : "center",
				hidden:true,
				sortable : false
			}, 
			{
				name : "sealStutas",
				index : "sealStutas",
				align : "center",
				sortable : false,
				formatter : function(value, options, rData) {
					return sealUseConstants.SealUseApplyStatusApply[value];
				}
			}
		],
		pager : "#useSealPagerApply",
		caption : "印章选择列表(Chop Selection List)"
	}).trigger("reloadGrid");
	$("#useSealListApply").navGrid("#useSealPagerApply", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};

/**
 * 打开印章选择窗口
 */
function openApplyDialog(){
	hasFile = false;
	$("#pageHeaderApply").dialog("open");
	initTaskListApply();
}

/**
 * 初始化印章选择弹窗
 */
function initApplyDialog(){
	$("#pageHeaderApply").dialog({
		autoOpen : false,
		resizable : false,
		height : $(window).height(),
		width : $(window).width()/9*8,
		modal : true,
		position : {
			at : "center"
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		}
	});
}

/**
 * 印章选择窗口选择机构
 */
function checkOrganizationItemApply(organizationNo) {
	//var organizationSid = "00000000000000000000000000000000";
	var organizationSid = top.loginPeopleInfo.orgSid;
	$("#organizationSid_ItemApply").radioOrgTree(true, organizationSid, 0, false, function(event, treeId, treeNode) {
		if (treeNode) {
			$("#organizationSid_ItemApply").val(treeNode.organizationName + "(" + treeNode.organizationNo + ")");
			$("#sealOrgNoApply").val(treeNode.organizationNo);
		}
	});
}

/**
 * 印章选择头部搜索框提交条件搜索
 */
function queryApplyInfoForTermApply() {
	$("#useSealListApply").jqGrid("search", "#queryFormApply");
};

//*********************************************					印章审批人窗口					******************************************************

/**
 * 初始化印章审批人列表
 */
function initTaskListSealApprover() {
	var sealautoId = $("#sealautoId").val();
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 195;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	var url = ctx+ "/mechseal/task/sealUseInstallAction_queryPeopleBysealSelf.action";
	$('#usePeopleListSealApprover').jqGrid('GridUnload');
	
	// 用印信息列表
	$("#usePeopleListSealApprover").jqGrid(
		{
			width : pageContentWidth,
			height : tableHeight + "px",
			url : url,
			multiselect : false,
			postData:{
				"sealautoId":sealautoId
			},
			rowNum : 1000,
			rownumbers : true,
			sortable : false,// 是否排序
			ondblClickRow : function(row) {
				var rowData = $("#usePeopleListSealApprover").getRowData(row);
				$("#apprPeopleName").val(rowData.peopleName)
				$("#apprPeopleSid").val(rowData.sid)
				$("#sealApproverDialog").dialog("close");
			},
			rowList : [ 20, 50, 100 ],
			colNames : [ "ID","用户姓名(User Name)", "用户代码(User Code)", "所属机构(Affiliated Institution)"],
			colModel : [
			    {
					name : "sid",
					index : "sid",
					align : "center",
					hidden:true,
					sortable : false
				},
				{
					name : "peopleName",
					index : "peopleName",
					align : "center",
					sortable : false
				}, 
				{
					name : "peopleCode",
					index : "peopleCode",
					align : "center",
					sortable : false
				}, 
				{
					name : "orgName",
					index : "orgName",
					align : "center",
					sortable : false
				}
			],
		pager : "#useSealPagerApprove",
		caption : "人员选择列表(User Selection List)"
	}).trigger("reloadGrid");
	$("#usePeopleListSealApprover").navGrid("#useSealPagerApprove", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
	
};

/**
 * 打开印章审批人窗口
 */
function openSealApproverDialog(){
	hasFile = false;
	var sealautoId= $("#sealautoId").val();
	if(sealautoId==""){
		alert("请选择印章！");
		return;
	}
	$("#sealApproverDialog").dialog("open");
	initTaskListSealApprover();
}

/**
 * 初始化印章选择弹窗
 */
function initSealApproverDialog(){
	$("#sealApproverDialog").dialog({
		autoOpen : false,
		resizable : false,
		height : $(window).height(),
		width : $(window).width()/9*8,
		modal : true,
		position : {
			at : "center"
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		}
	});
}

/**
 * 印章审批人窗口选择机构
 */
function checkOrganizationItemSealApprover(organizationNo) {
	//var organizationSid = "00000000000000000000000000000000";
	var organizationSid = top.loginPeopleInfo.orgSid;
	$("#organizationSid_ItemSealApprover").radioOrgTree(true, organizationSid, 0, false, function(event, treeId, treeNode) {
		if (treeNode) {
			$("#organizationSid_ItemSealApprover").val(treeNode.organizationName + "(" + treeNode.organizationNo + ")");
			$("#sealOrgNo").val(treeNode.organizationNo);
		}
	});
}

/**
 * 印章选择头部搜索框提交条件搜索
 */
function queryApplyInfoForTermSealApprover() {
	$("#usePeopleListSealApprover").jqGrid("search", "#queryFormSealApprover");
};
